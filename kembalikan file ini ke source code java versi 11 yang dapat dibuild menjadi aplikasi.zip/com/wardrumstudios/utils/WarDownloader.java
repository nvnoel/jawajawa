package com.wardrumstudios.utils;

import android.app.AlertDialog;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.PowerManager;
import android.support.v4.app.NotificationCompat;
import android.util.Log;
import android.view.SurfaceHolder;
import android.view.View;
import android.widget.LinearLayout;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Calendar;
import org.apache.commons.net.ftp.FTPClient;

public class WarDownloader {
    public String ACCEPT_EULA_BUTTON;
    public String ADDITIONAL_DATA_NEEDED;
    public String APPLICATION_EXITING_TEXT;
    public String CANCEL_BUTTON;
    public String CANNOT_DOWNLOAD_LL_DATA;
    public String CANNOT_WRITE_DATA;
    public String DATA_ACCESS_ERROR;
    public String DATA_ACCESS_ERROR_MESSAGE;
    public String DATA_INACCESSIBLE;
    public String DECLARE_EULA_BUTTON;
    public String DOWNLOADING_FILES_TEXT;
    public String DOWNLOAD_COMPLETE;
    ProgressDialog DownloadProgress;
    public String ESTIMATED_COMPLETION_TEXT;
    public String EULA1;
    public String EULA2;
    public String EULA3;
    public String EULA4;
    public String EXIT_BUTTON;
    public String EXPANDING_AUDIO_FILES;
    public String FATAL_AUDIO_EXTRACTION;
    public String FILES_TEXT;
    public String LICENSE_ERROR;
    public String LICENSE_ERROR_MESSAGE;
    public String LOADING_MESSAGE;
    public String MINUTES_TEXT;
    public String NEXT_BUTTON;
    public String NO_NETWORK;
    public String NO_WIFI;
    public String PLEASE_WAIT_TEXT;
    public String RETURN_TEXT;
    public String SECONDS_TEXT;
    byte[] buf;
    long[] currentRollingAmount;
    long[] currentRollingStart;
    long[] currentRollingTime;
    CDownloadFileList[] downloadFileList;
    NotificationCompat.Builder mBuilder;
    NotificationManager mNotifyManager;
    SurfaceHolder splashHolder;
    protected boolean UseAPKData = false;
    final String TAG = "DownloadManager";
    public int NumThreadsUnzipping = 0;
    public int filesUnzipped = 0;
    boolean UseLocalData = false;
    WarMedia myWarMedia = null;
    long downloadTime = 0;
    boolean ProgressInited = false;
    boolean BreakOut = false;
    long StartTime = 0;
    String currentDownloadingFile = null;
    public boolean UseFTP = false;
    public boolean UseMediaVault = true;
    boolean DownloadButUseLocalLocation = false;
    public boolean UseWardrumData = false;
    boolean DoDownloadTest = false;
    final boolean DoLog = false;
    final String OldDownloadCheckVersion = "Downloadv8";
    final String DownloadCheckVersion = "Downloadv9";
    final String VerifyCheckVersion = "VerifyV1";
    String baseRootDirectory = "/mnt/sdcard/GTA3/";
    private final String WardrumdownloadLocation = "http://wardrumstudios.com/MobileDownloads/gta3/";
    private final String WardrumFtpdownloadLocation = "MobileDownloads/gta3";
    private String downloadLocation = "";
    private String try1 = "";
    boolean IsDisplayingSpash = false;
    public int SpashIcon = 0;
    public long legalStartTime = 0;
    WarDownloader myWarDownloader = null;
    public int compressionScheme = 0;
    public String downloadTitle = "Vice City";
    boolean checkData = true;
    boolean splashViewCreated = false;
    String[] checkModels = {"models/gta3_unc.img", "models/gta3_dxt.img", "models/gta3_atc.img", "models/gta3_pvr.img"};
    boolean justCheckImg = false;
    boolean IOWriteError = false;
    int DownloadFailedMessage = 1;
    byte[] downloadBuffer = null;
    FTPClient ftpClient = null;
    MediaVault mv = null;
    boolean firstTry = true;
    long amountReallyDownloaded = 0;
    long amountDownloaded = 0;
    long timeToDownload = 0;
    long realTimeToDownload = 0;
    int filesToDownload = 0;
    int filesDownloaded = 0;
    long totalToDownload = 0;
    int lastUpdateBytes = 0;
    int rollIndex = -1;
    String notifyMessage = "";
    int CompressionType = -1;
    int numOfDownloadFiles = 0;

    public void SetKey(String key) {
        this.try1 = key;
    }

    public void SetLocation(String loc) {
        this.downloadLocation = loc;
    }

    public void SetWarMedia(WarMedia warMedia) {
        this.myWarMedia = warMedia;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void ShowEULA() {
        while (!this.myWarMedia.HasGLExtensions) {
            this.myWarMedia.mSleep(100L);
        }
        String version = this.myWarMedia.GetConfigSetting("DownloadCheckVersion");
        this.myWarMedia.GetConfigSetting("VerifyCheckVersion");
        boolean dataExists = version.equalsIgnoreCase("Downloadv9");
        if (dataExists) {
            boolean IsVerified = VerifyData();
            if (!IsVerified) {
                dataExists = false;
            } else {
                this.myWarMedia.SetConfigSetting("DownloadCheckVersion", "Downloadv9");
                this.myWarMedia.SetConfigSetting("VerifyCheckVersion", "VerifyV1");
            }
        }
        if (dataExists) {
            this.myWarMedia.DoResumeEvent();
            return;
        }
        String isEULAAccepted = this.myWarMedia.GetConfigSetting("VerifyCheckVersion");
        if (isEULAAccepted.equalsIgnoreCase("Yes")) {
            Runnable me = new Runnable() { // from class: com.wardrumstudios.utils.WarDownloader.1
                @Override // java.lang.Runnable
                public void run() {
                    WarDownloader.this.CheckAndDownload();
                }
            };
            this.myWarMedia.runOnUiThread(me);
            return;
        }
        String Eula = this.EULA2 + "\n\n" + this.EULA4 + "\n\n";
        final AlertDialog.Builder alert = new AlertDialog.Builder(this.myWarMedia).setMessage(Eula).setPositiveButton(this.ACCEPT_EULA_BUTTON, new DialogInterface.OnClickListener() { // from class: com.wardrumstudios.utils.WarDownloader.3
            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface i, int a) {
                i.dismiss();
                WarDownloader.this.myWarMedia.SetConfigSetting("VerifyCheckVersion", "Yes");
                Runnable me2 = new Runnable() { // from class: com.wardrumstudios.utils.WarDownloader.3.1
                    @Override // java.lang.Runnable
                    public void run() {
                        WarDownloader.this.CheckAndDownload();
                    }
                };
                WarDownloader.this.myWarMedia.runOnUiThread(me2);
            }
        }).setNegativeButton(this.DECLARE_EULA_BUTTON, new DialogInterface.OnClickListener() { // from class: com.wardrumstudios.utils.WarDownloader.2
            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface i, int a) {
                WarDownloader.this.myWarMedia.finish();
            }
        }).setCancelable(false);
        alert.setTitle("EULA");
        this.myWarMedia.runOnUiThread(new Runnable() { // from class: com.wardrumstudios.utils.WarDownloader.4
            @Override // java.lang.Runnable
            public void run() {
                AlertDialog al = alert.create();
                al.show();
            }
        });
    }

    void ClearSplash() {
        this.myWarMedia.runOnUiThread(new Runnable() { // from class: com.wardrumstudios.utils.WarDownloader.5
            @Override // java.lang.Runnable
            public void run() {
                if (WarDownloader.this.myWarMedia.splashView != null) {
                    WarDownloader.this.myWarMedia.splashView.setVisibility(8);
                }
                WarDownloader.this.myWarMedia.splashView = null;
            }
        });
    }

    void DisplaySplash() {
        try {
            LinearLayout.LayoutParams myParams = new LinearLayout.LayoutParams(-2, -2);
            this.myWarMedia.splashView = new View(this.myWarMedia);
            this.myWarMedia.addContentView(this.myWarMedia.splashView, myParams);
            Drawable dr = Drawable.createFromStream(this.myWarMedia.getAssets().open("SPLASH1.PNG"), null);
            this.myWarMedia.splashView.setBackgroundDrawable(dr);
        } catch (Exception e) {
            this.myWarMedia.splashView.setBackgroundResource(this.SpashIcon);
        }
        this.IsDisplayingSpash = true;
    }

    public boolean CheckCompressionFile() {
        CheckToSkipTexture("");
        System.out.println("Check for compression " + this.CompressionType);
        if (this.CompressionType >= 0) {
            File file = new File(this.baseRootDirectory + this.checkModels[this.CompressionType]);
            if (file.exists()) {
                return true;
            }
            System.out.println("File " + this.checkModels[this.CompressionType] + " does not exist for compression type " + this.CompressionType);
            return false;
        } else if (this.myWarMedia.glExtensions != "") {
            return true;
        } else {
            for (int i = 0; i < 4; i++) {
                File file2 = new File(this.baseRootDirectory + this.checkModels[i]);
                if (!file2.exists()) {
                    System.out.println("File " + this.checkModels[i] + " does not exist for compression type " + this.CompressionType);
                    return false;
                }
            }
            return true;
        }
    }

    void CheckAndDownload() {
        System.out.println("UseAPKData " + this.UseAPKData);
        if (this.UseAPKData) {
            this.myWarMedia.SetConfigSetting("DownloadCheckVersion", "Downloadv9");
            this.myWarMedia.DoResumeEvent();
            return;
        }
        if (!this.justCheckImg) {
            File gtaset = new File(this.baseRootDirectory + "gta3.set");
            if (gtaset.exists()) {
                gtaset.delete();
            }
        }
        CheckForDrive();
        while (!this.myWarMedia.HasGLExtensions) {
            System.out.println("wait for HasGLExtensions");
            this.myWarMedia.mSleep(10L);
        }
        DownloadDataCheck();
    }

    void DownloadDataCheck() {
        Runnable me = new Runnable() { // from class: com.wardrumstudios.utils.WarDownloader.6
            @Override // java.lang.Runnable
            public void run() {
                WarDownloader.this.DisplaySplash();
                if (WarDownloader.this.checkData) {
                    if (WarDownloader.this.myWarMedia.isNetworkAvailable()) {
                        if (WarDownloader.this.myWarMedia.isWiFiAvailable()) {
                            WarDownloader.this.DownloadDataMessage();
                            return;
                        } else {
                            WarDownloader.this.WiFiMessage();
                            return;
                        }
                    }
                    WarDownloader.this.ShowDownloadNetworkError();
                    return;
                }
                WarDownloader.this.myWarMedia.DoResumeEvent();
            }
        };
        this.myWarMedia.runOnUiThread(me);
    }

    void ShowDownloadNetworkError() {
        WarMedia warMedia = this.myWarMedia;
        String fTitle = this.NO_NETWORK;
        this.myWarMedia.runOnUiThread(new AnonymousClass7(fTitle));
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: com.wardrumstudios.utils.WarDownloader$7  reason: invalid class name */
    public class AnonymousClass7 implements Runnable {
        final  String val$fTitle;

        AnonymousClass7(String str) {
            this.val$fTitle = str;
        }

        @Override // java.lang.Runnable
        public void run() {
            AlertDialog exitDialog = new AlertDialog.Builder(WarDownloader.this.myWarMedia).setTitle(this.val$fTitle).setPositiveButton(WarDownloader.this.EXIT_BUTTON, new DialogInterface.OnClickListener() { // from class: com.wardrumstudios.utils.WarDownloader.7.2
                @Override // android.content.DialogInterface.OnClickListener
                public void onClick(DialogInterface i, int a) {
                    WarDownloader.this.myWarMedia.finish();
                }
            }).setNegativeButton(WarDownloader.this.NEXT_BUTTON, new DialogInterface.OnClickListener() { // from class: com.wardrumstudios.utils.WarDownloader.7.1
                @Override // android.content.DialogInterface.OnClickListener
                public void onClick(DialogInterface i, int a) {
                    WarDownloader.this.myWarMedia.runOnUiThread(new Runnable() { // from class: com.wardrumstudios.utils.WarDownloader.7.1.1
                        @Override // java.lang.Runnable
                        public void run() {
                            WarDownloader.this.DownloadDataCheck();
                        }
                    });
                }
            }).setCancelable(false).show();
            exitDialog.setCanceledOnTouchOutside(false);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: com.wardrumstudios.utils.WarDownloader$8  reason: invalid class name */
    public class AnonymousClass8 implements Runnable {
        AnonymousClass8() {
        }

        @Override // java.lang.Runnable
        public void run() {
            AlertDialog.Builder alert = new AlertDialog.Builder(WarDownloader.this.myWarMedia).setMessage(WarDownloader.this.NO_WIFI).setPositiveButton(WarDownloader.this.NEXT_BUTTON, new DialogInterface.OnClickListener() { // from class: com.wardrumstudios.utils.WarDownloader.8.2
                @Override // android.content.DialogInterface.OnClickListener
                public void onClick(DialogInterface i, int a) {
                    i.dismiss();
                    Runnable me = new Runnable() { // from class: com.wardrumstudios.utils.WarDownloader.8.2.1
                        @Override // java.lang.Runnable
                        public void run() {
                            WarDownloader.this.DownloadData();
                        }
                    };
                    new Thread(me).start();
                }
            }).setNegativeButton(WarDownloader.this.CANCEL_BUTTON, new DialogInterface.OnClickListener() { // from class: com.wardrumstudios.utils.WarDownloader.8.1
                @Override // android.content.DialogInterface.OnClickListener
                public void onClick(DialogInterface i, int a) {
                    WarDownloader.this.myWarMedia.finish();
                }
            }).setCancelable(false);
            AlertDialog al = alert.create();
            al.show();
        }
    }

    void WiFiMessage() {
        this.myWarMedia.runOnUiThread(new AnonymousClass8());
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: com.wardrumstudios.utils.WarDownloader$9  reason: invalid class name */
    public class AnonymousClass9 implements Runnable {
        AnonymousClass9() {
        }

        @Override // java.lang.Runnable
        public void run() {
            AlertDialog.Builder alert = new AlertDialog.Builder(WarDownloader.this.myWarMedia).setMessage(WarDownloader.this.ADDITIONAL_DATA_NEEDED).setPositiveButton(WarDownloader.this.NEXT_BUTTON, new DialogInterface.OnClickListener() { // from class: com.wardrumstudios.utils.WarDownloader.9.2
                @Override // android.content.DialogInterface.OnClickListener
                public void onClick(DialogInterface i, int a) {
                    i.dismiss();
                    Runnable me = new Runnable() { // from class: com.wardrumstudios.utils.WarDownloader.9.2.1
                        @Override // java.lang.Runnable
                        public void run() {
                            WarDownloader.this.DownloadData();
                        }
                    };
                    new Thread(me).start();
                }
            }).setNegativeButton(WarDownloader.this.CANCEL_BUTTON, new DialogInterface.OnClickListener() { // from class: com.wardrumstudios.utils.WarDownloader.9.1
                @Override // android.content.DialogInterface.OnClickListener
                public void onClick(DialogInterface i, int a) {
                    WarDownloader.this.myWarMedia.finish();
                }
            }).setCancelable(false);
            AlertDialog al = alert.create();
            al.show();
        }
    }

    void DownloadDataMessage() {
        this.myWarMedia.runOnUiThread(new AnonymousClass9());
    }

    boolean VerifyData() {
        if (!ReadFilelist()) {
            return true;
        }
        for (int filenum = 0; filenum < this.numOfDownloadFiles; filenum++) {
            String to = this.myWarMedia.baseDirectory + "/" + this.downloadFileList[filenum].filename;
            try {
                if (!CheckToSkipTexture(to)) {
                    File file = new File(to);
                    if (!file.exists() || this.downloadFileList[filenum].size != file.length()) {
                        return false;
                    }
                }
            } catch (Exception e) {
                return false;
            }
        }
        return true;
    }

    void CheckForDrive() {
        new File(this.baseRootDirectory);
    }

    boolean DownloadData() {
        if (DownloadAllFiles()) {
            this.buf = null;
        } else {
            this.buf = null;
            this.myWarMedia.runOnUiThread(new Runnable() { // from class: com.wardrumstudios.utils.WarDownloader.10
                @Override // java.lang.Runnable
                public void run() {
                    String errMess;
                    System.out.println("Data download failed");
                    if (WarDownloader.this.IOWriteError) {
                        errMess = WarDownloader.this.CANNOT_WRITE_DATA;
                    } else if (WarDownloader.this.DownloadFailedMessage == 1) {
                        errMess = WarDownloader.this.DATA_INACCESSIBLE;
                    } else {
                        errMess = WarDownloader.this.DownloadFailedMessage == 2 ? WarDownloader.this.CANNOT_DOWNLOAD_LL_DATA : WarDownloader.this.FATAL_AUDIO_EXTRACTION;
                    }
                    new AlertDialog.Builder(WarDownloader.this.myWarMedia).setMessage(errMess).setPositiveButton(WarDownloader.this.EXIT_BUTTON, new DialogInterface.OnClickListener() { // from class: com.wardrumstudios.utils.WarDownloader.10.1
                        @Override // android.content.DialogInterface.OnClickListener
                        public void onClick(DialogInterface i, int a) {
                            WarDownloader.this.myWarMedia.finish();
                        }
                    }).setCancelable(false).show();
                }
            });
        }
        this.myWarMedia.ClearSystemNotification();
        return true;
    }

    void ShowErrorMessage(int err) {
        this.myWarMedia.runOnUiThread(new Runnable() { // from class: com.wardrumstudios.utils.WarDownloader.11
            @Override // java.lang.Runnable
            public void run() {
                System.out.println("Data download failed");
                String errMess = WarDownloader.this.DATA_ACCESS_ERROR_MESSAGE;
                new AlertDialog.Builder(WarDownloader.this.myWarMedia).setMessage(errMess).setPositiveButton(WarDownloader.this.EXIT_BUTTON, new DialogInterface.OnClickListener() { // from class: com.wardrumstudios.utils.WarDownloader.11.1
                    @Override // android.content.DialogInterface.OnClickListener
                    public void onClick(DialogInterface i, int a) {
                        WarDownloader.this.myWarMedia.finish();
                    }
                }).setCancelable(false).show();
            }
        });
    }

    int CheckAndCreate(String to, int filesize) {
        File file = new File(to);
        if (file.exists() && (filesize == 0 || file.length() == filesize)) {
            return 1;
        }
        int last = to.lastIndexOf(47);
        String dir = to.substring(0, last);
        File path = new File(dir);
        path.mkdirs();
        return 0;
    }

    public boolean downloadFile(String filename) {
        return downloadFile(filename, 0, true) != 0;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public class progressFileOutputStream extends FileOutputStream {
        public boolean doCheck;
        int outputCount;

        public progressFileOutputStream(File file) throws FileNotFoundException {
            super(file);
            this.doCheck = true;
            this.outputCount = 0;
        }

        @Override // java.io.FileOutputStream, java.io.OutputStream
        public synchronized void write(byte[] b) throws IOException {
            super.write(b);
        }

        public synchronized void write(byte b) throws IOException {
            super.write((int) b);
        }

        @Override // java.io.FileOutputStream, java.io.OutputStream
        public synchronized void write(byte[] b, int off, int len) throws IOException {
            if (WarDownloader.this.BreakOut) {
                throw new IOException();
            }
            super.write(b, off, len);
            if (this.doCheck) {
                this.outputCount += len;
                WarDownloader.this.updateProgress(len, 0, true);
            }
        }
    }

    void downloadHttpFile(String from, String to) {
        try {
            System.currentTimeMillis();
            int exists = CheckAndCreate(to, 0);
            if (exists <= 0) {
                File file = new File(to);
                this.currentDownloadingFile = to;
                URL url = new URL(from);
                HttpURLConnection ucon = (HttpURLConnection) url.openConnection();
                if (ucon.getResponseCode() != 200) {
                    System.out.println("ERROR Downloading " + ucon.getResponseCode());
                    this.DownloadFailedMessage = 2;
                }
                InputStream is = ucon.getInputStream();
                FileOutputStream fos = new FileOutputStream(file);
                if (this.downloadBuffer == null) {
                    this.downloadBuffer = new byte[65536];
                }
                int totalBytes = 0;
                while (true) {
                    int numBytesRead = is.read(this.downloadBuffer, 0, 65536);
                    if (numBytesRead != -1) {
                        fos.write(this.downloadBuffer, 0, numBytesRead);
                        totalBytes += numBytesRead;
                    } else {
                        fos.close();
                        this.currentDownloadingFile = null;
                        return;
                    }
                }
            }
        } catch (IOException e) {
            Log.d("DownloadManager", "Error: " + e);
        }
    }

    static MediaVaultRequest getTimeParameters(String URL) {
        long unixNow = (Calendar.getInstance().getTimeInMillis() / 1000) - 3600;
        MediaVaultRequest options = new MediaVaultRequest(URL);
        options.setStartTime(unixNow);
        options.setEndTime(7200 + unixNow);
        return options;
    }

    private String GetVal(String tval) {
        String val = "";
        for (int i = 0; i < tval.length(); i += 2) {
            char t = tval.charAt(i + 1);
            int v = Integer.parseInt(tval.substring(i, i + 1));
            val = val + ((char) (t - v));
        }
        return val;
    }

    /*  JADX ERROR: ArrayIndexOutOfBoundsException in pass: ۥ۟ۡۤ۟
        java.lang.ArrayIndexOutOfBoundsException: length=2; index=652
        */
    public int downloadFile(java.lang.String r31, int r32, boolean r33) {
        /*
            Method dump skipped, instructions count: 996
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.wardrumstudios.utils.WarDownloader.downloadFile(java.lang.String, int, boolean):int");
    }

    ProgressDialog MakeProgressDialog() {
        ProgressDialog dialog = ProgressDialog.show(this.myWarMedia, "", this.LOADING_MESSAGE, true);
        return dialog;
    }

    void ClearDownloadVals() {
        this.amountReallyDownloaded = 0L;
        this.amountDownloaded = 0L;
        this.timeToDownload = 0L;
        this.realTimeToDownload = 0L;
        this.filesToDownload = 0;
        this.filesDownloaded = 0;
        this.totalToDownload = 0L;
        this.lastUpdateBytes = 0;
        this.rollIndex = -1;
    }

    void updateProgress(int bytes, int files, boolean isRealData) {
        int rate;
        boolean doUpdate = false;
        if (isRealData) {
            this.lastUpdateBytes += bytes;
            if (this.lastUpdateBytes > 1000000) {
                doUpdate = true;
            }
        } else {
            this.amountDownloaded += bytes;
            doUpdate = true;
        }
        this.filesDownloaded += files;
        if (doUpdate) {
            if (this.rollIndex == -1) {
                this.currentRollingAmount = new long[2];
                this.currentRollingStart = new long[2];
                this.currentRollingTime = new long[2];
                this.currentRollingAmount[0] = 0;
                this.currentRollingStart[0] = this.StartTime;
                this.currentRollingAmount[1] = 0;
                this.currentRollingStart[1] = this.StartTime;
                this.currentRollingTime[0] = 0;
                this.currentRollingTime[1] = 0;
                this.rollIndex = 0;
            }
            this.amountReallyDownloaded += this.lastUpdateBytes;
            this.amountDownloaded += this.lastUpdateBytes;
            long[] jArr = this.currentRollingAmount;
            int i = this.rollIndex;
            jArr[i] = jArr[i] + this.lastUpdateBytes;
            long[] jArr2 = this.currentRollingTime;
            int i2 = this.rollIndex;
            jArr2[i2] = jArr2[i2] + this.timeToDownload;
            this.timeToDownload = 0L;
            this.lastUpdateBytes = 0;
            String eta = "";
            this.timeToDownload = System.currentTimeMillis() - this.currentRollingStart[1 - this.rollIndex];
            long downsum = this.currentRollingAmount[0] + this.currentRollingAmount[1];
            if (this.timeToDownload > 0 && this.currentRollingAmount[0] > 0 && this.currentRollingAmount[1] > 0 && (rate = (int) (downsum / this.timeToDownload)) > 0) {
                int time = ((int) (this.totalToDownload - (this.amountDownloaded / 1024))) / rate;
                int minutes = time / 60;
                int seconds = time - (minutes * 60);
                eta = this.ESTIMATED_COMPLETION_TEXT + " " + minutes + " " + this.MINUTES_TEXT + " " + (minutes > 5 ? "" : seconds + " " + this.SECONDS_TEXT);
            }
            if (this.currentRollingAmount[this.rollIndex] > 50000000) {
                this.rollIndex = 1 - this.rollIndex;
                this.currentRollingStart[this.rollIndex] = System.currentTimeMillis();
                this.currentRollingAmount[this.rollIndex] = 0;
                this.currentRollingTime[this.rollIndex] = 0;
            }
            String mess = this.DOWNLOADING_FILES_TEXT + " (" + (this.filesToDownload - this.filesDownloaded) + " " + this.FILES_TEXT + " / " + ((this.totalToDownload - (this.amountDownloaded / 1024)) / 1024) + " MB) \n" + this.PLEASE_WAIT_TEXT;
            if (this.timeToDownload > 0) {
                mess = mess + "" + (downsum / this.timeToDownload) + " KB/s " + eta;
            }
            this.notifyMessage = "" + (this.filesToDownload - this.filesDownloaded) + " " + this.FILES_TEXT + " / " + ((this.totalToDownload - (this.amountDownloaded / 1024)) / 1024) + " MB ";
            if (this.timeToDownload > 0) {
                this.notifyMessage += "" + (downsum / this.timeToDownload) + " KB/s " + eta;
            }
            ChangeMessage(mess);
            if (this.DownloadProgress != null) {
                this.DownloadProgress.setProgress(((int) this.amountDownloaded) / 1024);
            }
            if (this.mBuilder != null) {
                this.mBuilder.setProgress((int) this.totalToDownload, ((int) this.amountDownloaded) / 1024, false);
                this.mNotifyManager.notify(0, this.mBuilder.build());
            }
        }
    }

    boolean GetCompressionType() {
        if (this.CompressionType == -1) {
            if (this.myWarMedia.glExtensions == "") {
                System.out.println("No glextensions - download all");
                return false;
            } else if (this.compressionScheme == 0) {
                if (this.myWarMedia.glExtensions.contains("GL_EXT_texture_compression_dxt1")) {
                    this.CompressionType = 1;
                } else if (this.myWarMedia.glExtensions.contains("GL_AMD_compressed_ATC_texture")) {
                    this.CompressionType = 1;
                } else if (this.myWarMedia.glExtensions.contains("GL_IMG_texture_compression_pvrtc")) {
                    this.CompressionType = 3;
                } else {
                    this.CompressionType = 0;
                }
            } else if (this.compressionScheme == 1) {
                if (this.myWarMedia.glExtensions.contains("GL_EXT_texture_compression_dxt1")) {
                    this.CompressionType = 1;
                } else if (this.myWarMedia.glExtensions.contains("GL_AMD_compressed_ATC_texture")) {
                    this.CompressionType = 2;
                } else if (this.myWarMedia.glExtensions.contains("GL_IMG_texture_compression_pvrtc")) {
                    this.CompressionType = 3;
                } else {
                    this.CompressionType = 0;
                }
            }
        }
        return true;
    }

    boolean CheckToSkipTexture(String filename) {
        if (this.CompressionType == -1) {
            if (this.myWarMedia.glExtensions == null || this.myWarMedia.glExtensions == "") {
                System.out.println("No glextensions - download all");
                return false;
            } else if (this.compressionScheme == 0) {
                if (this.myWarMedia.glExtensions.contains("GL_EXT_texture_compression_dxt1")) {
                    this.CompressionType = 1;
                } else if (this.myWarMedia.glExtensions.contains("GL_AMD_compressed_ATC_texture")) {
                    this.CompressionType = 1;
                } else if (this.myWarMedia.glExtensions.contains("GL_IMG_texture_compression_pvrtc")) {
                    this.CompressionType = 3;
                } else {
                    this.CompressionType = 0;
                }
            } else if (this.compressionScheme == 1) {
                if (this.myWarMedia.glExtensions.contains("GL_EXT_texture_compression_dxt1")) {
                    this.CompressionType = 1;
                } else if (this.myWarMedia.glExtensions.contains("GL_AMD_compressed_ATC_texture")) {
                    this.CompressionType = 2;
                } else if (this.myWarMedia.glExtensions.contains("GL_IMG_texture_compression_pvrtc")) {
                    this.CompressionType = 3;
                } else {
                    this.CompressionType = 0;
                }
            }
        }
        if (filename.contains("DXT")) {
            return this.CompressionType != 1;
        } else if (this.compressionScheme == 1 && filename.contains("ATC")) {
            return this.CompressionType != 2;
        } else if (filename.contains("PVR")) {
            return this.CompressionType != 3;
        } else if (this.compressionScheme == 0 && filename.contains("ETC")) {
            return this.CompressionType != 0;
        } else if (this.compressionScheme == 1 && filename.contains("UNC")) {
            return this.CompressionType != 0;
        } else {
            return false;
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public class CDownloadFileList {
        boolean downloaded;
        int downloadsize;
        String filename;
        int size;
        boolean unzipped;

        CDownloadFileList() {
        }
    }

    boolean ReadFilelist() {
        try {
            InputStream is = this.myWarMedia.getAssets().open("filelist.txt");
            BufferedReader input = new BufferedReader(new InputStreamReader(is));
            int lineCount = 0;
            int numFilesToDownload = 0;
            while (true) {
                String line = input.readLine();
                if (line == null) {
                    break;
                }
                if (lineCount == 0) {
                    this.filesToDownload = Integer.decode(line).intValue();
                    this.numOfDownloadFiles = Integer.decode(line).intValue();
                    this.downloadFileList = new CDownloadFileList[this.numOfDownloadFiles];
                } else if (lineCount == 1) {
                    this.totalToDownload = Integer.decode(line).intValue();
                } else if (lineCount - 2 > this.filesToDownload) {
                    System.out.println("Error lineCount " + lineCount + " filesToDownload " + this.filesToDownload);
                    break;
                } else {
                    this.downloadFileList[numFilesToDownload] = new CDownloadFileList();
                    this.downloadFileList[numFilesToDownload].filename = line.substring(11);
                    this.downloadFileList[numFilesToDownload].size = Integer.decode(line.substring(0, 10).trim()).intValue();
                    if (!CheckToSkipTexture(this.downloadFileList[numFilesToDownload].filename)) {
                        this.downloadFileList[numFilesToDownload].downloaded = false;
                        this.downloadFileList[numFilesToDownload].downloadsize = 0;
                        this.downloadFileList[numFilesToDownload].unzipped = !this.downloadFileList[numFilesToDownload].filename.contains(".zip");
                        numFilesToDownload++;
                    } else {
                        this.numOfDownloadFiles--;
                        this.totalToDownload -= this.downloadFileList[numFilesToDownload].size / 1024;
                    }
                }
                lineCount++;
            }
            input.close();
            return true;
        } catch (Exception ex) {
            System.out.println("ERROR in ReadFilelist " + ex.getMessage());
            return false;
        }
    }

    void UpdateDownloadList() {
        int totalSize = 0;
        int numFiles = 0;
        for (int filenum = 0; filenum < this.numOfDownloadFiles; filenum++) {
            String to = this.myWarMedia.baseDirectory + "/" + this.downloadFileList[filenum].filename;
            try {
                if (!CheckToSkipTexture(to)) {
                    File file = new File(to);
                    if (file.exists() && this.downloadFileList[filenum].size == file.length()) {
                        this.downloadFileList[filenum].downloaded = true;
                    } else {
                        totalSize += this.downloadFileList[filenum].size;
                        numFiles++;
                    }
                }
            } catch (Exception e) {
                totalSize += this.downloadFileList[filenum].size;
                numFiles++;
            }
        }
        this.filesToDownload = numFiles;
        this.totalToDownload = totalSize / 1024;
        this.filesDownloaded = 0;
    }

    /* JADX WARN: Code restructure failed: missing block: B:115:?, code lost:
        return false;
     */
    /* JADX WARN: Code restructure failed: missing block: B:32:0x01eb, code lost:
        java.lang.System.out.println("Failed Downloading 3 times read " + r18 + " expected " + r32.downloadFileList[r13].size);
     */
    /* JADX WARN: Code restructure failed: missing block: B:34:0x0221, code lost:
        if (r24 == null) goto L92;
     */
    /* JADX WARN: Code restructure failed: missing block: B:35:0x0223, code lost:
        r24.release();
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    boolean DownloadAllFiles() {
        final Context mContext = this.myWarMedia;
        final WarMedia fWarMedia = this.myWarMedia;
        PowerManager.WakeLock wakeLock = null;
        this.myWarMedia.handler.post(new Runnable() { // from class: com.wardrumstudios.utils.WarDownloader.12
            @Override // java.lang.Runnable
            public void run() {
                WarDownloader.this.mNotifyManager = (NotificationManager) WarDownloader.this.myWarMedia.getSystemService("notification");
                WarDownloader.this.mBuilder = new NotificationCompat.Builder(WarDownloader.this.myWarMedia);
                WarDownloader.this.mBuilder.setContentTitle(WarDownloader.this.downloadTitle).setContentText(WarDownloader.this.DOWNLOADING_FILES_TEXT + ", " + WarDownloader.this.PLEASE_WAIT_TEXT).setSmallIcon(WarDownloader.this.myWarMedia.appStatusIcon);
                Intent notificationIntent = fWarMedia.appIntent;
                notificationIntent.addFlags(536870912);
                PendingIntent resultPendingIntent = PendingIntent.getActivity(WarDownloader.this.myWarMedia, 0, notificationIntent, 134217728);
                WarDownloader.this.mBuilder.setContentIntent(resultPendingIntent);
                WarDownloader.this.DownloadProgress = new ProgressDialog(mContext);
                WarDownloader.this.DownloadProgress.setProgressStyle(1);
                WarDownloader.this.DownloadProgress.setMessage(WarDownloader.this.DOWNLOADING_FILES_TEXT + ", " + WarDownloader.this.PLEASE_WAIT_TEXT);
                WarDownloader.this.DownloadProgress.setButton(-1, WarDownloader.this.CANCEL_BUTTON, new DialogInterface.OnClickListener() { // from class: com.wardrumstudios.utils.WarDownloader.12.1
                    @Override // android.content.DialogInterface.OnClickListener
                    public void onClick(DialogInterface i, int a) {
                        if (WarDownloader.this.currentDownloadingFile != null) {
                            File file = new File(WarDownloader.this.currentDownloadingFile);
                            file.delete();
                        }
                        WarDownloader.this.myWarMedia.finish();
                    }
                });
                WarDownloader.this.DownloadProgress.setCancelable(false);
                WarDownloader.this.DownloadProgress.setCanceledOnTouchOutside(false);
                WarDownloader.this.DownloadProgress.show();
                WarDownloader.this.ProgressInited = true;
            }
        });
        int ret = -1;
        boolean Result = true;
        if (!this.DoDownloadTest) {
            try {
                try {
                    this.StartTime = System.currentTimeMillis();
                    PowerManager pm = (PowerManager) mContext.getSystemService("power");
                    wakeLock = pm.newWakeLock(1, "OSWrapper");
                    wakeLock.acquire();
                } catch (Exception ex) {
                    ex.printStackTrace();
                    ret = -1;
                    if (wakeLock != null) {
                        wakeLock.release();
                    }
                }
                if (!ReadFilelist()) {
                    return false;
                }
                UpdateDownloadList();
                do {
                    try {
                    } catch (Exception ex2) {
                        ex2.printStackTrace();
                        ret = -1;
                    }
                } while (!this.ProgressInited);
                ChangeMessage(this.DOWNLOADING_FILES_TEXT + ". " + this.PLEASE_WAIT_TEXT);
                if (this.totalToDownload > 5) {
                    ChangeMessage(this.DOWNLOADING_FILES_TEXT + " (" + this.filesToDownload + " " + this.FILES_TEXT + " / " + (this.totalToDownload / 1024) + " MB). " + this.PLEASE_WAIT_TEXT);
                    if (this.DownloadProgress != null) {
                        this.DownloadProgress.setMax((int) this.totalToDownload);
                    }
                    if (this.mBuilder != null) {
                        this.mBuilder.setContentText(this.DOWNLOADING_FILES_TEXT + " (" + this.filesToDownload + " " + this.FILES_TEXT + " / " + (this.totalToDownload / 1024) + " MB). " + this.PLEASE_WAIT_TEXT);
                        this.mNotifyManager.notify(0, this.mBuilder.build());
                    }
                }
                int filenum = 0;
                loop1: while (filenum < this.numOfDownloadFiles) {
                    if (!this.downloadFileList[filenum].downloaded) {
                        long curTime = System.currentTimeMillis();
                        ret = 0;
                        int count = 0;
                        boolean doUnzipFile = true;
                        while (true) {
                            int count2 = count;
                            if (ret == this.downloadFileList[filenum].size) {
                                break;
                            }
                            count = count2 + 1;
                            if (count2 > 3) {
                                break loop1;
                            }
                            if (count > 0) {
                                System.out.println("Download " + this.downloadFileList[filenum].filename + " failed size " + ret + " expected " + this.downloadFileList[filenum].size);
                            }
                            if (CheckToSkipTexture(this.downloadFileList[filenum].filename)) {
                                ret = -3;
                                break;
                            }
                            ret = downloadFile(this.downloadFileList[filenum].filename, this.downloadFileList[filenum].size, true);
                            if (ret == -2) {
                                System.out.println("Download " + this.downloadFileList[filenum].filename + " already exists");
                                doUnzipFile = false;
                                ret = 0;
                                break;
                            }
                        }
                        long timeDiff = System.currentTimeMillis() - curTime;
                        if (timeDiff == 0) {
                            timeDiff = 1;
                        }
                        if (ret == 0 || ret == -3) {
                            ret = this.downloadFileList[filenum].size;
                            updateProgress(ret, 1, false);
                        } else {
                            this.realTimeToDownload += timeDiff;
                            this.timeToDownload += this.downloadTime;
                            this.amountReallyDownloaded += ret;
                            updateProgress(0, 1, false);
                        }
                        if (ret == -3) {
                            this.downloadFileList[filenum].unzipped = true;
                            this.downloadFileList[filenum].downloaded = true;
                        }
                        if (ret != -3) {
                            if (!doUnzipFile) {
                                this.downloadFileList[filenum].unzipped = true;
                            }
                            this.downloadFileList[filenum].downloaded = true;
                        }
                        if (ret == -1) {
                            break;
                        }
                    }
                    filenum++;
                }
                if (wakeLock != null) {
                    wakeLock.release();
                }
                Result = ret != -1;
            } finally {
                if (wakeLock != null) {
                    wakeLock.release();
                }
            }
        }
        if (this.UseFTP) {
            try {
                this.ftpClient.disconnect();
                this.ftpClient = null;
            } catch (Exception e) {
            }
        }
        if (Result) {
            if (!VerifyData()) {
                this.DownloadFailedMessage = 3;
                return false;
            }
            this.myWarMedia.SetConfigSetting("DownloadCheckVersion", "Downloadv9");
            ChangeMessage("Done Downloading");
        }
        this.downloadBuffer = null;
        return Result;
    }

    void ChangeMessage(String message) {
        if (this.myWarMedia.paused && message == "Done Downloading") {
            this.myWarMedia.runOnUiThread(new Runnable() { // from class: com.wardrumstudios.utils.WarDownloader.13
                @Override // java.lang.Runnable
                public void run() {
                    WarDownloader.this.mBuilder.setContentText(WarDownloader.this.DOWNLOAD_COMPLETE);
                    WarDownloader.this.mBuilder.setProgress(0, 0, false);
                    WarDownloader.this.mNotifyManager.cancel(0);
                    WarDownloader.this.mNotifyManager.notify(0, WarDownloader.this.mBuilder.build());
                }
            });
            while (this.myWarMedia.paused) {
                this.myWarMedia.mSleep(1000L);
            }
        }
        this.myWarMedia.handler.post(new AnonymousClass14(message));
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: com.wardrumstudios.utils.WarDownloader$14  reason: invalid class name */
    public class AnonymousClass14 implements Runnable {
        final  String val$mess;

        AnonymousClass14(String str) {
            this.val$mess = str;
        }

        @Override // java.lang.Runnable
        public void run() {
            if (this.val$mess == "Done Downloading") {
                if (WarDownloader.this.DownloadProgress != null) {
                    WarDownloader.this.DownloadProgress.dismiss();
                }
                WarDownloader.this.DownloadProgress = null;
                long elapsed = System.currentTimeMillis() - WarDownloader.this.StartTime;
                String newMess = elapsed > 300000 ? "" + (elapsed / 60000) + " " + WarDownloader.this.MINUTES_TEXT : "" + (elapsed / 1000) + " " + WarDownloader.this.SECONDS_TEXT;
                WarDownloader.this.mBuilder.setContentText(WarDownloader.this.DOWNLOAD_COMPLETE + " (" + newMess + ")");
                new AlertDialog.Builder(WarDownloader.this.myWarMedia).setMessage(WarDownloader.this.DOWNLOAD_COMPLETE + " (" + newMess + ")").setPositiveButton(WarDownloader.this.NEXT_BUTTON, new DialogInterface.OnClickListener() { // from class: com.wardrumstudios.utils.WarDownloader.14.2
                    @Override // android.content.DialogInterface.OnClickListener
                    public void onClick(DialogInterface i, int a) {
                        WarDownloader.this.myWarMedia.runOnUiThread(new Runnable() { // from class: com.wardrumstudios.utils.WarDownloader.14.2.1
                            @Override // java.lang.Runnable
                            public void run() {
                                WarDownloader.this.ClearSplash();
                                WarDownloader.this.myWarMedia.DoResumeEvent();
                            }
                        });
                    }
                }).setNegativeButton(WarDownloader.this.EXIT_BUTTON, new DialogInterface.OnClickListener() { // from class: com.wardrumstudios.utils.WarDownloader.14.1
                    @Override // android.content.DialogInterface.OnClickListener
                    public void onClick(DialogInterface i, int a) {
                        WarDownloader.this.myWarMedia.finish();
                    }
                }).setCancelable(false).show();
            } else if (this.val$mess == "Done Downloading Language") {
                if (WarDownloader.this.DownloadProgress != null) {
                    WarDownloader.this.DownloadProgress.dismiss();
                }
                WarDownloader.this.DownloadProgress = null;
            } else {
                if (WarDownloader.this.DownloadProgress != null) {
                    WarDownloader.this.DownloadProgress.setMessage(this.val$mess);
                }
                if (WarDownloader.this.mBuilder != null) {
                    WarDownloader.this.mBuilder.setContentText(WarDownloader.this.notifyMessage);
                    WarDownloader.this.mNotifyManager.notify(0, WarDownloader.this.mBuilder.build());
                }
            }
        }
    }
}