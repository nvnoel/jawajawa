package com.wardrumstudios.utils;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Looper;
import android.util.Log;
import com.google.android.gms.appstate.AppStateManager;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.ResultCallback;
import com.google.android.gms.games.Games;
import com.google.android.gms.games.achievement.AchievementBuffer;
import com.google.android.gms.games.achievement.Achievements;
import com.google.android.gms.games.leaderboard.LeaderboardBuffer;
import com.google.android.gms.games.leaderboard.LeaderboardScore;
import com.google.android.gms.games.leaderboard.LeaderboardScoreBuffer;
import com.google.android.gms.games.leaderboard.Leaderboards;
import com.google.android.gms.games.snapshot.Snapshot;
import com.google.android.gms.games.snapshot.SnapshotMetadata;
import com.google.android.gms.games.snapshot.SnapshotMetadataChange;
import com.google.android.gms.games.snapshot.Snapshots;
import com.google.example.games.basegameutils.GameHelper;
import java.util.ArrayList;
import java.util.List;

public class WarGameService implements GameHelper.GameHelperListener, ResultCallback<AppStateManager.StateResult>, WarActivityLifecycleListener {
    public static final int CLIENT_ALL = 15;
    public static final int CLIENT_APPSTATE = 4;
    public static final int CLIENT_DRIVE = 8;
    public static final int CLIENT_GAMES = 1;
    public static final int CLIENT_PLUS = 2;
    public static final int RC_SHOWSNAPSHOTLIST = 8321;
    private static final String TAG = "WarGameService";
    private WarBase mActivity;
    protected GameHelper mHelper;
    ArrayList<LeaderboardQuery> queries;
    private boolean isPaused = false;
    protected int mRequestedClients = 1;
    protected String mDebugTag = TAG;
    protected boolean mDebugLog = true;
    protected boolean creatingGamehelper = true;
    byte[] savedScreenshot = null;

    public native void notifyAchievementsLoaded(String[] strArr, boolean[] zArr, int[] iArr, int[] iArr2);

    public native void notifyLeaderboardScoreQuery(int i, float[] fArr, String[] strArr);

    public native void notifySignInChange(boolean z);

    public native void notifySignInFailed();

    public native void notifySnapshotCountLoaded(int i);

    public native void notifySnapshotLoading();

    public native void notifySnapshotSelected(byte[] bArr);

    public native void notifyStateConflict(int i, String str, byte[] bArr, byte[] bArr2);

    public native void notifyStateLoaded(int i, int i2, byte[] bArr);

    protected WarGameService(WarBase activity) {
        this.mActivity = activity;
        Runnable myRun = new Runnable() { // from class: com.wardrumstudios.utils.WarGameService.1
            @Override // java.lang.Runnable
            public void run() {
                myWarGameService.mActivity.AddLifecycleListener(myWarGameService);
                myWarGameService.mHelper = WarGameService.this.getGameHelper();
                myWarGameService.setRequestedClients(15);
                myWarGameService.mHelper.setup(myWarGameService);
                myWarGameService.onStart();
                myWarGameService.creatingGamehelper = false;
            }
        };
        this.mActivity.runOnUiThread(myRun);
        int hangCount = 0;
        if (Looper.getMainLooper().getThread() != Thread.currentThread()) {
            while (this.creatingGamehelper) {
                int hangCount2 = hangCount + 1;
                if (hangCount < 10) {
                    this.mActivity.mSleep(100L);
                    hangCount = hangCount2;
                } else {
                    return;
                }
            }
        }
    }

    public GameHelper getGameHelper() {
        if (this.mHelper == null) {
            this.mHelper = new GameHelper(this.mActivity, this.mRequestedClients);
            this.mHelper.enableDebugLog(this.mDebugLog);
        }
        return this.mHelper;
    }

    protected void setRequestedClients(int requestedClients) {
        this.mRequestedClients = requestedClients;
    }

    @Override // com.wardrumstudios.utils.WarActivityLifecycleListener
    public void onActivityResult(int request, int response, Intent data) {
        if (request == 8321) {
            switch (response) {
                case -1:
                    notifySnapshotLoading();
                    SnapshotMetadata metadata = data.getParcelableExtra("com.google.android.gms.games.SNAPSHOT_METADATA");
                    Games.Snapshots.open(getApiClient(), metadata).setResultCallback(new ResultCallback<Snapshots.OpenSnapshotResult>() { // from class: com.wardrumstudios.utils.WarGameService.2
                        public void onResult(Snapshots.OpenSnapshotResult result) {
                            switch (result.getStatus().getStatusCode()) {
                                case 0:
                                    byte[] data2 = result.getSnapshot().readFully();
                                    WarGameService.this.notifySnapshotSelected(data2);
                                    return;
                                case 4004:
                                    WarGameService.this.debugLog("Conflict while opening the selected snapshot, resolving...");
                                    Snapshot latest = result.getSnapshot();
                                    Snapshot conflict = result.getConflictingSnapshot();
                                    WarGameService.this.debugLog("conflict = " + conflict);
                                    WarGameService.this.debugLog("latest = " + latest);
                                    WarGameService.this.debugLog("conflictId = " + result.getConflictId());
                                    Games.Snapshots.resolveConflict(WarGameService.this.getApiClient(), result.getConflictId(), conflict).setResultCallback(new ResultCallback<Snapshots.OpenSnapshotResult>() { // from class: com.wardrumstudios.utils.WarGameService.2.1
                                        public void onResult(Snapshots.OpenSnapshotResult result2) {
                                            switch (result2.getStatus().getStatusCode()) {
                                                case 0:
                                                    byte[] data3 = result2.getSnapshot().readFully();
                                                    WarGameService.this.notifySnapshotSelected(data3);
                                                    return;
                                                default:
                                                    WarGameService.this.notifySnapshotSelected(null);
                                                    WarGameService.this.debugLog("Failed to save snapshot, status:" + result2.getStatus());
                                                    return;
                                            }
                                        }
                                    });
                                    return;
                                default:
                                    WarGameService.this.notifySnapshotSelected(null);
                                    WarGameService.this.debugLog("Failed to open snapshot, status:" + result.getStatus());
                                    return;
                            }
                        }
                    });
                    return;
                default:
                    return;
            }
        }
        this.mHelper.onActivityResult(request, response, data);
    }

    protected GoogleApiClient getApiClient() {
        return this.mHelper.getApiClient();
    }

    protected boolean isSignedIn() {
        return this.mHelper.isSignedIn();
    }

    @Override // com.wardrumstudios.utils.WarActivityLifecycleListener
    public void onStart() {
        this.mHelper.onStart(this.mActivity);
    }

    @Override // com.wardrumstudios.utils.WarActivityLifecycleListener
    public void onPause() {
        this.isPaused = true;
        debugLog("onPause OpenSnapshotResult mActivity.paused " + this.mActivity.paused);
        this.mHelper.onPause();
    }

    @Override // com.wardrumstudios.utils.WarActivityLifecycleListener
    public void onStop() {
        this.mHelper.onStop();
    }

    @Override // com.wardrumstudios.utils.WarActivityLifecycleListener
    public void onDestroy() {
        this.mHelper.onStop();
    }

    @Override // com.wardrumstudios.utils.WarActivityLifecycleListener
    public void onResume() {
        this.isPaused = false;
    }

    public void onSignInSucceeded() {
        Games.Achievements.load(getApiClient(), false).setResultCallback(new ResultCallback<Achievements.LoadAchievementsResult>() { // from class: com.wardrumstudios.utils.WarGameService.3
            public void onResult(Achievements.LoadAchievementsResult result) {
                int statusCode = result.getStatus().getStatusCode();
                AchievementBuffer buffer = result.getAchievements();
                WarGameService.this.debugLog("Achivements loaded!");
                if (statusCode != 0) {
                    WarGameService.this.debugLog("Error while loading achievements.");
                    return;
                }
                int count = buffer.getCount();
                String[] ids = new String[count];
                boolean[] states = new boolean[count];
                int[] steps = new int[count];
                int[] totalSteps = new int[count];
                for (int i = 0; i < count; i++) {
                    ids[i] = buffer.get(i).getAchievementId();
                    states[i] = buffer.get(i).getState() == 0;
                    if (buffer.get(i).getType() == 1) {
                        steps[i] = buffer.get(i).getCurrentSteps();
                        totalSteps[i] = buffer.get(i).getTotalSteps();
                    } else {
                        steps[i] = -1;
                        totalSteps[i] = -1;
                    }
                }
                WarGameService.this.debugLog("Notifying down to native");
                WarGameService.this.notifyAchievementsLoaded(ids, states, steps, totalSteps);
                WarGameService.this.debugLog("Done. Notifying down to native");
                buffer.close();
            }
        });
        notifySignInChange(true);
    }

    public void onSignInFailed() {
        notifySignInFailed();
    }

    public void onLeaderboardMetadataLoaded(int statusCode, LeaderboardBuffer buffer) {
    }

    protected void enableDebugLog(boolean enabled, String tag) {
        this.mDebugLog = true;
        this.mDebugTag = tag;
        if (this.mHelper != null) {
            this.mHelper.enableDebugLog(enabled);
        }
    }

    void debugLog(String message) {
        if (this.mDebugLog) {
            Log.d(this.mDebugTag, "WarGameService: " + message);
        }
    }

    protected String getInvitationId() {
        return this.mHelper.getInvitationId();
    }

    protected boolean hasSignInError() {
        return this.mHelper.hasSignInError();
    }

    protected GameHelper.SignInFailureReason getSignInError() {
        return this.mHelper.getSignInError();
    }

    public void ShowSignInUI() {
        if (!this.mHelper.isSignedIn()) {
            this.mHelper.beginUserInitiatedSignIn();
        }
    }

    public void SignOut() {
        this.mHelper.signOut();
    }

    public boolean GetConnectionStatus() {
        return this.mHelper.isSignedIn();
    }

    public void RefreshData(boolean forceReload) {
    }

    public String GetPlayerName() {
        String playerName = "default";
        try {
            if (!this.mHelper.isSignedIn()) {
                return "default";
            }
            playerName = Games.Players.getCurrentPlayer(getApiClient()).getDisplayName();
            System.out.println("GetPlayerName " + playerName);
            return playerName;
        } catch (Exception e) {
            return playerName;
        }
    }

    public void ShowAchievementList() {
        if (this.mHelper.isSignedIn()) {
            this.mActivity.startActivityForResult(Games.Achievements.getAchievementsIntent(getApiClient()), 0);
        } else {
            debugLog("The GamesClient is not connected so the achievement list cannot be shown.");
        }
    }

    public void UnlockAchievement(String id) {
        debugLog("Unlocking Achievement: " + id);
        if (this.mHelper.isSignedIn()) {
            Games.Achievements.unlock(getApiClient(), id);
            debugLog("Done Unlocking Achievement: " + id);
            return;
        }
        debugLog("Trying to unlock an achievement while the achievements are not available.");
    }

    public void IncrementAchievement(String id, int numSteps) {
        if (this.mHelper.isSignedIn()) {
            Games.Achievements.increment(getApiClient(), id, numSteps);
        } else {
            debugLog("Trying to unlock an achievement but we're not signed in.");
        }
    }

    public void ShowLeaderboards() {
        if (this.mHelper.isSignedIn()) {
            this.mActivity.startActivityForResult(Games.Leaderboards.getAllLeaderboardsIntent(getApiClient()), 0);
        } else {
            debugLog("The GamesClient is not connected so the leaderboards cannot be shown.");
        }
    }

    public void ShowLeaderboard(String id) {
        if (this.mHelper.isSignedIn()) {
            String gameLeaderboardId = this.mActivity.GetLeaderboardId(id);
            this.mActivity.startActivityForResult(Games.Leaderboards.getLeaderboardIntent(getApiClient(), gameLeaderboardId), 0);
            return;
        }
        debugLog("The GamesClient is not connected so the requested leaderboard cannot be shown.");
    }

    public void SubmitScore(String leaderboardId, long score) {
        if (this.mHelper.isSignedIn()) {
            String gameLeaderboardId = this.mActivity.GetLeaderboardId(leaderboardId);
            Games.Leaderboards.submitScore(getApiClient(), gameLeaderboardId, score);
            return;
        }
        debugLog("The GamesClient is not connected so the new score cannot be submitted to the leaderboards cannot be shown.");
    }

    class LeaderboardQuery {
        int queryId;
        PendingResult<Leaderboards.LoadScoresResult> result;

        LeaderboardQuery() {
        }
    }

    public void SubmitLeaderboardQuery(String leaderboardName, int numResuts, int startIndex, int queryId, boolean showFriends, boolean sortAscending) {
        if (this.mHelper.isSignedIn()) {
            String gameLeaderboardId = this.mActivity.GetLeaderboardId(leaderboardName);
            debugLog("SubmitLeaderboardQuery " + gameLeaderboardId);
            int friendCollection = showFriends ? 1 : 0;
            System.out.println("SubmitLeaderboardQuery " + gameLeaderboardId + " friendCollection " + friendCollection);
            PendingResult<Leaderboards.LoadScoresResult> result = Games.Leaderboards.loadTopScores(getApiClient(), gameLeaderboardId, 2, friendCollection, numResuts, true);
            processPendingResult(queryId, result);
            return;
        }
        debugLog("The GamesClient is not connected so the requested leaderboard cannot be shown.");
    }

    public void CancelLeaderboardQuery(int queryId) {
        debugLog("CancelLeaderboardQuery");
    }

    public void getPlayerCenteredScores(String leaderboardID, int timeSpan, int collection) {
        Games.Leaderboards.loadPlayerCenteredScores(getApiClient(), leaderboardID, timeSpan, collection, 25, true);
    }

    protected void processPendingResult(final int queryId, PendingResult<Leaderboards.LoadScoresResult> pendingScores) {
        pendingScores.setResultCallback(new ResultCallback<Leaderboards.LoadScoresResult>() { // from class: com.wardrumstudios.utils.WarGameService.4
            public void onResult(Leaderboards.LoadScoresResult loadScoresResult) {
                List<LeaderboardScore> leaderboardScores = WarGameService.this.extractScores(loadScoresResult);
                WarGameService.this.notifyScoresLoaded(queryId, leaderboardScores);
            }
        });
    }

    protected List<LeaderboardScore> extractScores(Leaderboards.LoadScoresResult loadScoresResult) {
        LeaderboardScoreBuffer buffer = loadScoresResult.getScores();
        List<LeaderboardScore> leaderboardScores = new ArrayList<>();
        for (int i = 0; i < buffer.getCount(); i++) {
            leaderboardScores.add(buffer.get(i));
        }
        return leaderboardScores;
    }

    public void notifyScoresLoaded(int queryId, List<LeaderboardScore> scoreList) {
        System.out.println("notifyScoresLoaded " + scoreList.size());
        float[] scores = new float[scoreList.size()];
        String[] names = new String[scoreList.size()];
        for (int i = 0; i < scoreList.size(); i++) {
            scores[i] = (float) scoreList.get(i).getRawScore();
            names[i] = scoreList.get(i).getScoreHolder().getDisplayName();
            String scoreStr = scoreList.get(i).getDisplayScore();
            System.out.println("notifyScoresLoaded " + names[i] + " score " + scores[i] + " scorestr " + scoreStr);
        }
        notifyLeaderboardScoreQuery(queryId, scores, names);
    }

    public void SaveToCloud(byte[] data) {
        if (this.mHelper.isSignedIn()) {
            AppStateManager.updateImmediate(getApiClient(), 0, data).setResultCallback(this);
        } else {
            debugLog("The GamesClient is not connected so data cannot be saved to the cloud.");
        }
    }

    public void LoadFromCloud() {
        if (this.mHelper.isSignedIn()) {
            AppStateManager.load(getApiClient(), 0).setResultCallback(this);
        } else {
            debugLog("The GamesClient is not connected so data cannot be saved to the cloud.");
        }
    }

    public void ResolveState(String resolvedVersion, byte[] data) {
        AppStateManager.resolve(getApiClient(), 0, resolvedVersion, data).setResultCallback(this);
    }

    public void onResult(AppStateManager.StateResult result) {
        AppStateManager.StateConflictResult conflictResult = result.getConflictResult();
        AppStateManager.StateLoadedResult loadedResult = result.getLoadedResult();
        if (loadedResult != null) {
            notifyStateLoaded(loadedResult.getStatus().getStatusCode(), loadedResult.getStateKey(), loadedResult.getLocalData());
        } else if (conflictResult != null) {
            notifyStateConflict(conflictResult.getStateKey(), conflictResult.getResolvedVersion(), conflictResult.getLocalData(), conflictResult.getServerData());
        }
        if (loadedResult != null) {
            loadedResult.release();
        }
        if (conflictResult != null) {
            conflictResult.release();
        }
    }

    public void ShowSnapshotList() {
        this.mActivity.startActivityForResult(Games.Snapshots.getSelectSnapshotIntent(getApiClient(), "Saved Snapshots", false, true, 10000), RC_SHOWSNAPSHOTLIST);
    }

    public void LoadSnapshotCount() {
        Games.Snapshots.load(getApiClient(), false).setResultCallback(new ResultCallback<Snapshots.LoadSnapshotsResult>() { // from class: com.wardrumstudios.utils.WarGameService.5
            public void onResult(Snapshots.LoadSnapshotsResult result) {
                switch (result.getStatus().getStatusCode()) {
                    case 0:
                        WarGameService.this.notifySnapshotCountLoaded(result.getSnapshots().getCount());
                        result.getSnapshots().close();
                        return;
                    default:
                        WarGameService.this.debugLog("Failed to load snapshots, status:" + result.getStatus());
                        return;
                }
            }
        });
    }

    public class OpenSnapshotResultHandler implements ResultCallback<Snapshots.OpenSnapshotResult> {
        private byte[] data;
        private String description;
        private String name;
        private long playedMS;
        private byte[] screenshot;

        public OpenSnapshotResultHandler(String name, String description, byte[] data, byte[] screenshot, long playedMS) {
            this.name = name;
            this.description = description;
            this.data = data;
            this.screenshot = screenshot;
            this.playedMS = playedMS;
        }

        public void onResult(Snapshots.OpenSnapshotResult result) {
            switch (result.getStatus().getStatusCode()) {
                case 0:
                    if (result.getSnapshot().writeBytes(this.data)) {
                        Bitmap bitmap = null;
                        if (this.screenshot != null) {
                            WarGameService.this.debugLog("screenshot " + this.screenshot);
                            WarGameService.this.debugLog("screenshot.length " + this.screenshot.length);
                            bitmap = BitmapFactory.decodeByteArray(this.screenshot, 0, this.screenshot.length);
                            WarGameService.this.debugLog("bitmap " + bitmap);
                        }
                        SnapshotMetadataChange.Builder metadataBuilder = new SnapshotMetadataChange.Builder();
                        metadataBuilder.setDescription(this.description);
                        if (this.playedMS > 0) {
                            metadataBuilder.setPlayedTimeMillis(this.playedMS);
                        }
                        if (bitmap != null) {
                            metadataBuilder.setCoverImage(bitmap);
                        }
                        SnapshotMetadataChange metadata = metadataBuilder.build();
                        Games.Snapshots.commitAndClose(WarGameService.this.getApiClient(), result.getSnapshot(), metadata);
                        return;
                    }
                    return;
                case 4004:
                    WarGameService.this.debugLog("Conflict while saving, resolving...");
                    result.getSnapshot();
                    Snapshot conflict = result.getConflictingSnapshot();
                    Games.Snapshots.resolveConflict(WarGameService.this.getApiClient(), result.getConflictId(), conflict).setResultCallback(new OpenSnapshotResultHandler(this.name, this.description, this.data, this.screenshot, this.playedMS));
                    return;
                default:
                    WarGameService.this.debugLog("Failed to save snapshot, status:" + result.getStatus());
                    return;
            }
        }
    }

    public void SaveScreenshot(byte[] screenshot) {
        this.savedScreenshot = screenshot;
    }

    public void SaveSnapshot(final String name, final String description, final byte[] data, final long playedMS) {
        debugLog("Saving snapshot...");
        if (this.isPaused) {
            try {
                Snapshots.OpenSnapshotResult result = Games.Snapshots.open(getApiClient(), name, true).await();
                switch (result.getStatus().getStatusCode()) {
                    case 0:
                        debugLog("OpenSnapshotResult");
                        if (result.getSnapshot().writeBytes(data)) {
                            SnapshotMetadataChange.Builder metadataBuilder = new SnapshotMetadataChange.Builder();
                            metadataBuilder.setDescription(description);
                            if (playedMS > 0) {
                                metadataBuilder.setPlayedTimeMillis(playedMS);
                            }
                            SnapshotMetadataChange metadata = metadataBuilder.build();
                            Games.Snapshots.commitAndClose(getApiClient(), result.getSnapshot(), metadata);
                            return;
                        }
                        return;
                    case 4004:
                        debugLog("Conflict while saving, resolving...");
                        result.getSnapshot();
                        Snapshot conflict = result.getConflictingSnapshot();
                        Snapshots.OpenSnapshotResult conflictResult = Games.Snapshots.resolveConflict(getApiClient(), result.getConflictId(), conflict).await();
                        if (conflictResult.getStatus().getStatusCode() == 0) {
                        }
                        return;
                    default:
                        debugLog("Failed to save snapshot, status:" + result.getStatus());
                        return;
                }
            } catch (IllegalStateException e) {
                debugLog("Snapshot IllegalStateException");
                return;
            }
        }
        new Thread(new Runnable() { // from class: com.wardrumstudios.utils.WarGameService.6
            @Override // java.lang.Runnable
            public void run() {
                while (WarGameService.this.savedScreenshot == null && !description.contains("InUse save")) {
                    try {
                        Thread.sleep(100L);
                        WarGameService.this.debugLog("SaveSnapshot waiting for screenshot for " + description);
                    } catch (InterruptedException e2) {
                    }
                }
                try {
                    WarGameService.this.debugLog("SaveSnapshot trying to save");
                    Games.Snapshots.open(WarGameService.this.getApiClient(), name, true).setResultCallback(new OpenSnapshotResultHandler(name, description, data, WarGameService.this.savedScreenshot, playedMS));
                    WarGameService.this.savedScreenshot = null;
                } catch (IllegalStateException e3) {
                    WarGameService.this.debugLog("Snapshot IllegalStateException");
                }
            }
        }).start();
    }

    public void DeleteSnapshot(String name) {
        debugLog("Deleting snapshot...");
        try {
            Games.Snapshots.open(getApiClient(), name, false).setResultCallback(new ResultCallback<Snapshots.OpenSnapshotResult>() { // from class: com.wardrumstudios.utils.WarGameService.7
                public void onResult(Snapshots.OpenSnapshotResult result) {
                    switch (result.getStatus().getStatusCode()) {
                        case 0:
                            SnapshotMetadata metadata = result.getSnapshot().getMetadata();
                            Games.Snapshots.delete(WarGameService.this.getApiClient(), metadata).setResultCallback(new ResultCallback<Snapshots.DeleteSnapshotResult>() { // from class: com.wardrumstudios.utils.WarGameService.7.1
                                public void onResult(Snapshots.DeleteSnapshotResult result2) {
                                    int status = result2.getStatus().getStatusCode();
                                    if (status == 0) {
                                        WarGameService.this.debugLog("Successfully deleted snapshot.");
                                    } else {
                                        WarGameService.this.debugLog("Error deleting snapshot! status: " + status);
                                    }
                                }
                            });
                            return;
                        case 4000:
                            WarGameService.this.debugLog("Tried to delete a non-existent snapshot.");
                            return;
                        default:
                            WarGameService.this.debugLog("Failed to delete snapshot, status:" + result.getStatus());
                            return;
                    }
                }
            });
        } catch (IllegalStateException e) {
            debugLog("Snapshot ");
        }
    }

    public void DeleteAllSnapshots() {
        throw new UnsupportedOperationException();
    }
}