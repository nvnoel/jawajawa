package com.wardrumstudios.utils;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.AlertDialog;
import android.app.KeyguardManager;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.UiModeManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.res.AssetManager;
import android.content.res.Configuration;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Point;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.hardware.Camera;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.net.wifi.WifiManager;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Messenger;
import android.os.PowerManager;
import android.os.Process;
import android.os.Vibrator;
import android.provider.Settings;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.telephony.TelephonyManager;
import android.text.TextPaint;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import com.bda.controller.Constants;
import com.fastman92.main_activity_launcher.Settings;
import com.google.android.vending.expansion.downloader.DownloadProgressInfo;
import com.google.android.vending.expansion.downloader.DownloaderClientMarshaller;
import com.google.android.vending.expansion.downloader.DownloaderServiceMarshaller;
import com.google.android.vending.expansion.downloader.Helpers;
import com.google.android.vending.expansion.downloader.IDownloaderClient;
import com.google.android.vending.expansion.downloader.IDownloaderService;
import com.google.android.vending.expansion.downloader.IStub;
import com.nvidia.devtech.NvUtil;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileFilter;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.Locale;
import java.util.UUID;
import java.util.regex.Pattern;

public class WarMedia extends WarGamepad implements MediaPlayer.OnPreparedListener, MediaPlayer.OnCompletionListener, MediaPlayer.OnSeekCompleteListener, MediaPlayer.OnErrorListener, IDownloaderClient {
    static final int REQUEST_READ_EXTERNAL_STORAGE = 8001;
    public boolean AddMovieExtension;
    protected boolean AllowLongPressForExit;
    String DeviceCountry;
    public String DeviceLocale;
    boolean DisplayMovieTextOnTap;
    final boolean DoLog;
    boolean GameIsFocused;
    protected int HELLO_ID;
    boolean IsInValidation;
    int IsShowingBackMessage;
    boolean MovieIsSkippable;
    boolean MovieTextDisplayed;
    protected int SpecialBuildType;
    protected boolean UseExpansionFiles;
    final boolean UsingSounds;
    Activity activity;
    protected CharSequence appContentText;
    protected CharSequence appContentTitle;
    protected Intent appIntent;
    protected int appStatusIcon;
    protected CharSequence appTickerText;
    AudioManager audioManager;
    int audioMax;
    int audioVolume;
    int availableMemory;
    int bIsPlayingMovie;
    boolean bMoviePlayerPaused;
    public String baseDirectory;
    public String baseDirectoryRoot;
    protected int baseDisplayHeight;
    protected int baseDisplayWidth;
    protected int cachedSizeRead;
    protected boolean checkForMaxDisplaySize;
    LinearLayout col1;
    LinearLayout col2;
    LinearLayout col3;
    String currentMovieFilename;
    int currentMovieLength;
    int currentMovieMS;
    int currentMovieOffset;
    float currentMovieVolume;
    int currentTempID;
    SurfaceHolder customMovieHolder;
    SurfaceView customMovieSurface;
    public MediaPlayer dialogPlayer;
    SurfaceHolder downloadHolder;
    SurfaceView downloadView;
    boolean downloadViewCreated;
    AlertDialog exitDialog;
    protected boolean hasTouchScreen;
    boolean isCompleting;
    boolean isPhone;
    long lastMovieStop;
    protected int lastNetworkAvailable;
    public LinearLayout llSplashView;
    public String localIp;
    private Locale locale;
    int mAscent;
    private TextView mAverageSpeed;
    Camera mCamera;
    private boolean mCancelValidation;
    private View mCellMessage;
    private View mDashboard;
    private IStub mDownloaderClientStub;
    private ProgressBar mPB;
    private Button mPauseButton;
    private TextView mProgressFraction;
    private TextView mProgressPercent;
    private final BroadcastReceiver mReceiver;
    private IDownloaderService mRemoteService;
    private int mState;
    private boolean mStatePaused;
    private TextView mStatusText;
    Paint mTextPaint;
    private TextView mTimeRemaining;
    private Button mWiFiSettingsButton;
    private WifiManager mWifiManager;
    ActivityManager.MemoryInfo memInfo;
    int memoryThreshold;
    protected DisplayMetrics metrics;
    ActivityManager mgr;
    int movieLooping;
    public MediaPlayer moviePlayer;
    String movieSubtitleText;
    boolean movieTextDisplayNow;
    SurfaceHolder movieTextHolder;
    int movieTextScale;
    SurfaceView movieTextSurface;
    TextView movieTextView;
    LinearLayout movieView;
    boolean movieViewCreated;
    int movieViewHeight;
    boolean movieViewIsActive;
    TextView movieViewText;
    int movieViewWidth;
    int movieViewX;
    int movieViewY;
    SurfaceHolder movieWindowHolder;
    SurfaceView movieWindowSurface;
    public MediaPlayer musicPlayer;
    int[] myPid;
    private Vibrator myVib;
    private PowerManager.WakeLock myWakeLock;
    protected byte[] privateData;
    protected String[] privateDataFiles;
    LinearLayout row1;
    LinearLayout row2;
    LinearLayout row3;
    TextPaint sTextPaint;
    float screenWidthInches;
    boolean skipMovies;
    boolean skipSound;
    boolean soundLog;
    ArrayList<PoolInfo> sounds;
    Paint tPaint;
    TextPaint textPaint;
    int totalMemory;
    long[][] vibrateEffects;
    protected String expansionFileName = "";
    protected String patchFileName = "";
    protected String apkFileName = "";
    protected boolean overrideExpansionName = false;
    public XAPKFile[] xAPKS = null;
    public boolean waitForPermissions = false;
    boolean KeepAspectRatio = true;
    boolean ForceSize = false;
    protected boolean UseFTPDownload = false;
    public boolean UseWarDownloader = true;
    public WarDownloader wardown = null;
    private boolean isUserPresent = true;
    private boolean IsScreenPaused = false;

    private native void initTouchSense(Context context);

    public native void NativeNotifyNetworkChange(int i);

    public native void setTouchSenseFilepath(String str);

    public WarMedia() {
        this.DoLog = !this.FinalRelease;
        this.moviePlayer = null;
        this.skipSound = false;
        this.skipMovies = false;
        this.isCompleting = false;
        this.bIsPlayingMovie = 0;
        this.soundLog = false;
        this.DisplayMovieTextOnTap = false;
        this.movieSubtitleText = "";
        this.movieTextDisplayNow = false;
        this.SpecialBuildType = 0;
        this.activity = null;
        this.HELLO_ID = 12346;
        this.appStatusIcon = 0;
        this.appTickerText = "MyApp";
        this.appContentTitle = "MyApp";
        this.appContentText = "Running - Return to Game?";
        this.appIntent = null;
        this.UseExpansionFiles = false;
        this.AllowLongPressForExit = false;
        this.hasTouchScreen = true;
        this.isPhone = false;
        this.currentTempID = 100000;
        this.baseDirectory = "/mnt/sdcard/";
        this.baseDirectoryRoot = "/mnt/sdcard/";
        this.AddMovieExtension = true;
        this.IsShowingBackMessage = 0;
        this.exitDialog = null;
        this.cachedSizeRead = 0;
        this.UsingSounds = false;
        this.memoryThreshold = 0;
        this.availableMemory = 0;
        this.totalMemory = 0;
        this.screenWidthInches = 0.0f;
        this.baseDisplayWidth = 1920;
        this.baseDisplayHeight = 1080;
        this.lastNetworkAvailable = -1;
        this.checkForMaxDisplaySize = false;
        this.mWifiManager = null;
        this.downloadViewCreated = false;
        this.GameIsFocused = false;
        this.mReceiver = new BroadcastReceiver() { // from class: com.wardrumstudios.utils.WarMedia.9
            @Override // android.content.BroadcastReceiver
            public void onReceive(Context context, Intent intent) {
                String action = intent.getAction();
                if (!WarMedia.this.FinalRelease) {
                    System.out.println("BroadcastReceiver WarMedia " + action.toString());
                }
                if ("android.intent.action.SCREEN_OFF".equals(action)) {
                    if (!WarMedia.this.FinalRelease) {
                        System.out.println("BroadcastReceiver ACTION_SCREEN_OFF");
                    }
                    WarMedia.this.isUserPresent = false;
                } else if ("android.intent.action.USER_PRESENT".equals(action) || "android.intent.action.SCREEN_ON".equals(action)) {
                    if (!WarMedia.this.FinalRelease) {
                        System.out.println("BroadcastReceiver " + action);
                    }
                    KeyguardManager keyguardManager = (KeyguardManager) WarMedia.this.getSystemService("keyguard");
                    if (!WarMedia.this.FinalRelease) {
                        System.out.println("inKeyguardRestrictedInputMode " + keyguardManager.inKeyguardRestrictedInputMode());
                    }
                    if (!keyguardManager.inKeyguardRestrictedInputMode()) {
                        WarMedia.this.isUserPresent = true;
                        if (WarMedia.this.IsScreenPaused) {
                            WarMedia.this.IsScreenPaused = false;
                            if (WarMedia.this.viewIsActive) {
                                WarMedia.this.resumeEvent();
                                if (WarMedia.this.cachedSurfaceHolder != null) {
                                    WarMedia.this.cachedSurfaceHolder.setKeepScreenOn(true);
                                }
                            }
                            if (!WarMedia.this.paused) {
                                WarMedia.this.PauseMoviePlayer(false);
                            }
                        }
                    }
                } else if (intent.getAction().equals("android.net.conn.CONNECTIVITY_CHANGE")) {
                    WarMedia.this.NetworkChange();
                } else if (WarMedia.this.DoLog) {
                    System.out.println("Received " + action.toString());
                }
            }
        };
        this.bMoviePlayerPaused = false;
        this.currentMovieMS = 0;
        this.currentMovieFilename = "";
        this.currentMovieOffset = 0;
        this.currentMovieLength = 0;
        this.currentMovieVolume = 0.5f;
        this.myVib = null;
        this.vibrateEffects = new long[][]{new long[]{0, 100, 100, 100, 100}, new long[]{0, 100, 50, 75, 100, 50, 100}, new long[]{0, 25, 50, 100, 50, 25, 100}, new long[]{0, 25, 50, 25, 100, 100, 100}, new long[]{0, 50, 50, 50, 50, 25, 100}};
        this.mgr = null;
        this.memInfo = null;
        this.myPid = null;
        this.MovieIsSkippable = false;
        this.lastMovieStop = 0L;
        this.movieWindowSurface = null;
        this.movieWindowHolder = null;
        this.movieTextHolder = null;
        this.movieTextSurface = null;
        this.movieViewIsActive = false;
        this.movieViewCreated = false;
        this.customMovieHolder = null;
        this.customMovieSurface = null;
        this.movieViewWidth = 0;
        this.movieViewHeight = 0;
        this.movieViewX = 0;
        this.movieViewY = 0;
        this.movieLooping = 0;
        this.movieView = null;
        this.movieViewText = null;
        this.DeviceLocale = "";
        this.DeviceCountry = "";
        this.locale = null;
        this.IsInValidation = false;
        this.movieTextScale = 32;
        this.movieTextView = null;
        this.MovieTextDisplayed = false;
        this.llSplashView = null;
    }

    public static class XAPKFile {
        public final long mFileSize;
        public final int mFileVersion;
        public final boolean mIsMain;

        public XAPKFile(boolean isMain, int fileVersion, long fileSize) {
            this.mIsMain = isMain;
            this.mFileVersion = fileVersion;
            this.mFileSize = fileSize;
        }
    }

    class PoolInfo {
        float duration;
        String filename;
        float lv;
        float rv;
        int soundID;

        PoolInfo() {
        }
    }

    void GetMaxDisplaySize() {
        if (Build.VERSION.SDK_INT >= 11) {
            Display display = getWindowManager().getDefaultDisplay();
            Point size = new Point();
            display.getSize(size);
            System.out.println("width=" + size.x + " height=" + size.y);
            if (this.maxDisplayWidth < size.x) {
                this.maxDisplayWidth = size.x;
                this.maxDisplayHeight = size.y;
            }
            Display.Mode[] modes = display.getSupportedModes();
            for (int i = 0; i < modes.length; i++) {
                Display.Mode mode = modes[i];
                if (this.maxDisplayWidth < mode.getPhysicalWidth()) {
                    this.maxDisplayWidth = mode.getPhysicalWidth();
                    this.maxDisplayHeight = mode.getPhysicalHeight();
                }
                System.out.println("mode " + i + " width=" + mode.getPhysicalWidth() + " height=" + mode.getPhysicalHeight());
            }
        }
    }

    @Override // com.wardrumstudios.utils.WarGamepad, com.wardrumstudios.utils.WarBilling, com.wardrumstudios.utils.WarBase, com.nvidia.devtech.NvEventQueueActivity, android.app.Activity
    public void onCreate(Bundle savedInstanceState) {
        if (this.isNativeApp) {
            super.onCreate(savedInstanceState);
        }
        if (this.DoLog) {
            System.out.println("****WarMedia onCreate");
        }
        ClearSystemNotification();
        GetGameBaseDirectory();
        this.GetGLExtensions = this.UseFTPDownload;
        if (IsPortrait()) {
            if (Build.VERSION.SDK_INT >= 9) {
                setRequestedOrientation(7);
            } else {
                setRequestedOrientation(1);
            }
        } else if (Build.VERSION.SDK_INT >= 9) {
            setRequestedOrientation(6);
        } else {
            setRequestedOrientation(0);
        }
        this.metrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(this.metrics);
        System.out.println("Display Metrics Info:\n\tdensity:\t\t" + this.metrics.density + "\n\tdensityDPI:\t\t" + this.metrics.densityDpi + "\n\tscaledDensity:\t\t" + this.metrics.scaledDensity + "\n\twidthDPI:\t\t" + this.metrics.xdpi + "\n\theightDPI:\t\t" + this.metrics.ydpi + "\n\twidthPixels:\t\t" + this.metrics.widthPixels + "\n\theightPixels:\t\t" + this.metrics.heightPixels + "\n\tscreenlayout=" + getResources().getConfiguration().screenLayout);
        this.maxDisplayWidth = this.metrics.widthPixels;
        this.maxDisplayHeight = this.metrics.heightPixels;
        this.baseDisplayWidth = this.metrics.widthPixels;
        this.baseDisplayHeight = this.metrics.heightPixels;
        if (!IsPortrait() && this.metrics.widthPixels < this.metrics.heightPixels) {
            this.maxDisplayWidth = this.metrics.heightPixels;
            this.maxDisplayHeight = this.metrics.widthPixels;
            this.baseDisplayWidth = this.metrics.heightPixels;
            this.baseDisplayHeight = this.metrics.widthPixels;
        }
        if (Build.MODEL.startsWith("ADT")) {
            this.IsAndroidTV = true;
        }
        if (Build.MANUFACTURER.startsWith("NVIDIA") && Build.MODEL.startsWith("SHIELD Android TV")) {
            if (this.checkForMaxDisplaySize) {
                GetMaxDisplaySize();
            }
            this.isShieldTV = true;
        }
        NvUtil.getInstance().setActivity(this);
        NvUtil.getInstance().setAppLocalValue("STORAGE_ROOT", this.baseDirectory);
        NvUtil.getInstance().setAppLocalValue("STORAGE_ROOT_BASE", this.baseDirectoryRoot);
        this.hasTouchScreen = getResources().getConfiguration().touchscreen != 1;
        System.out.println("hastouchscreen " + this.hasTouchScreen + " touchscreen " + getResources().getConfiguration().touchscreen);
        this.activity = this;
        GetRealLocale();
        PowerManager pm = (PowerManager) getSystemService("power");
        this.myWakeLock = pm.newWakeLock(268435482, "WarEngine");
        this.myWakeLock.setReferenceCounted(false);
        this.isPhone = IsPhone();
        this.screenWidthInches = this.metrics.widthPixels / this.metrics.xdpi;
        if (this.isPhone) {
            if (this.screenWidthInches < 3.5f) {
                this.screenWidthInches = 3.5f;
            }
            if (this.screenWidthInches > 6.0f) {
                this.screenWidthInches = 6.0f;
            }
        } else {
            if (this.screenWidthInches < 6.0f) {
                this.screenWidthInches = 6.0f;
            }
            if (this.screenWidthInches > 10.0f) {
                this.screenWidthInches = 10.0f;
            }
        }
        setVolumeControlStream(3);
        this.audioManager = (AudioManager) getSystemService("audio");
        this.audioMax = this.audioManager.getStreamMaxVolume(3);
        this.audioVolume = this.audioManager.getStreamVolume(3);
        int processors = Runtime.getRuntime().availableProcessors();
        System.out.println("availableProcessors " + processors + " cpu " + getNumberOfProcessors());
        GetMemoryInfo(true);
        if (this.UseSubtitles) {
            SetPaint(-16711936, 16);
        }
        this.localIp = getLocalIpAddress();
        if (!this.isNativeApp) {
            super.onCreate(savedInstanceState);
        }
        if (!CustomLoadFunction()) {
            localHasGameData();
        }
        NetworkChange();
        try {
            initTouchSense(this);
        } catch (UnsatisfiedLinkError e) {
        }
    }

    public boolean isTV() {
        UiModeManager uiModeManager = (UiModeManager) getSystemService("uimode");
        return uiModeManager.getCurrentModeType() == 4;
    }

    public boolean isWiFiAvailable() {
        if (this.mWifiManager == null) {
            this.mWifiManager = (WifiManager) getSystemService("wifi");
        }
        return this.mWifiManager != null && this.mWifiManager.isWifiEnabled();
    }

    public boolean isNetworkAvailable() {
        NetworkInfo activeNetworkInfo;
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService("connectivity");
        if (connectivityManager == null || (activeNetworkInfo = connectivityManager.getActiveNetworkInfo()) == null) {
            return false;
        }
        return activeNetworkInfo.isConnected();
    }

    void ShowGPDownloadError() {
        runOnUiThread(new AnonymousClass1(this));
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: com.wardrumstudios.utils.WarMedia$1  reason: invalid class name */
    public class AnonymousClass1 implements Runnable {
        final  Activity val$myActivity;

        AnonymousClass1(Activity activity) {
            this.val$myActivity = activity;
        }

        @Override // java.lang.Runnable
        public void run() {
            WarMedia.this.exitDialog = new AlertDialog.Builder(this.val$myActivity).setTitle("Unknown download error. Please reinstall from Google Play").setPositiveButton("Quit Game", new DialogInterface.OnClickListener() { // from class: com.wardrumstudios.utils.WarMedia.1.2
                @Override // android.content.DialogInterface.OnClickListener
                public void onClick(DialogInterface i, int a) {
                    WarMedia.this.finish();
                }
            }).setNegativeButton("Retry", new DialogInterface.OnClickListener() { // from class: com.wardrumstudios.utils.WarMedia.1.1
                @Override // android.content.DialogInterface.OnClickListener
                public void onClick(DialogInterface i, int a) {
                    WarMedia.this.runOnUiThread(new Runnable() { // from class: com.wardrumstudios.utils.WarMedia.1.1.1
                        @Override // java.lang.Runnable
                        public void run() {
                            WarMedia.this.localHasGameData();
                        }
                    });
                }
            }).setCancelable(false).show();
            WarMedia.this.exitDialog.setCanceledOnTouchOutside(false);
        }
    }

    void ShowDownloadNetworkError() {
        runOnUiThread(new AnonymousClass2(this));
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: com.wardrumstudios.utils.WarMedia$2  reason: invalid class name */
    public class AnonymousClass2 implements Runnable {
        final  Activity val$myActivity;

        AnonymousClass2(Activity activity) {
            this.val$myActivity = activity;
        }

        @Override // java.lang.Runnable
        public void run() {
            WarMedia.this.exitDialog = new AlertDialog.Builder(this.val$myActivity).setTitle("No network connection. Cannot download game data.").setPositiveButton("Quit Game", new DialogInterface.OnClickListener() { // from class: com.wardrumstudios.utils.WarMedia.2.2
                @Override // android.content.DialogInterface.OnClickListener
                public void onClick(DialogInterface i, int a) {
                    WarMedia.this.finish();
                }
            }).setNegativeButton("Continue", new DialogInterface.OnClickListener() { // from class: com.wardrumstudios.utils.WarMedia.2.1
                @Override // android.content.DialogInterface.OnClickListener
                public void onClick(DialogInterface i, int a) {
                    WarMedia.this.runOnUiThread(new Runnable() { // from class: com.wardrumstudios.utils.WarMedia.2.1.1
                        @Override // java.lang.Runnable
                        public void run() {
                            WarMedia.this.localHasGameData();
                        }
                    });
                }
            }).setCancelable(false).show();
            WarMedia.this.exitDialog.setCanceledOnTouchOutside(false);
        }
    }

    public int downloadFTPFile(String filename, int filesize, boolean check) {
        return 0;
    }

    protected boolean localHasGameData() {
        if (!this.FinalRelease) {
            System.out.println("localHasGameData");
        }
        if (this.UseFTPDownload) {
            new Thread(new Runnable() { // from class: com.wardrumstudios.utils.WarMedia.3
                @Override // java.lang.Runnable
                public void run() {
                    WarMedia.this.wardown.ShowEULA();
                }
            }).start();
            return false;
        }
        if (this.xAPKS == null || expansionFilesDelivered()) {
            AfterDownloadFunction();
        } else {
            Intent notifierIntent = new Intent(this, getClass());
            notifierIntent.setFlags(335544320);
            PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, notifierIntent, 134217728);
            try {
                int startResult = DownloaderClientMarshaller.startDownloadServiceIfRequired(this, pendingIntent, WarDownloaderService.class);
                System.out.println("localHasGameData startDownloadServiceIfRequired startResult " + startResult);
                if (startResult != 0) {
                    if (!this.FinalRelease) {
                        System.out.println("localHasGameData != NO_DOWNLOAD_REQUIRED");
                    }
                    if (isNetworkAvailable()) {
                        initializeDownloadUI();
                        return false;
                    }
                    ShowDownloadNetworkError();
                    return false;
                } else if (!expansionFilesDelivered()) {
                    ShowGPDownloadError();
                    return false;
                } else {
                    AfterDownloadFunction();
                }
            } catch (PackageManager.NameNotFoundException e) {
                e.printStackTrace();
            }
        }
        return true;
    }

    public String GetGameBaseDirectory() {
        if (Environment.getExternalStorageState().equals("mounted")) {
            try {
                File f = Settings.getExternalFilesDir(this);
                String base = f.getAbsolutePath();
                int index = base.indexOf("/Android");
                this.baseDirectoryRoot = base.substring(0, index);
                return f.getAbsolutePath() + "/";
            } catch (NullPointerException e) {
            } catch (Exception e2) {
            }
        }
        ShowSDErrorDialog();
        return "";
    }

    void ShowSDErrorDialog() {
        runOnUiThread(new Runnable() { // from class: com.wardrumstudios.utils.WarMedia.4
            @Override // java.lang.Runnable
            public void run() {
                WarMedia.this.exitDialog = new AlertDialog.Builder(this).setTitle("Cannot find storage. Is SDCard mounted?").setPositiveButton("Exit Game", new DialogInterface.OnClickListener() { // from class: com.wardrumstudios.utils.WarMedia.4.1
                    @Override // android.content.DialogInterface.OnClickListener
                    public void onClick(DialogInterface i, int a) {
                        WarMedia.this.finish();
                    }
                }).setCancelable(false).show();
                WarMedia.this.exitDialog.setCanceledOnTouchOutside(true);
            }
        });
    }

    boolean expansionFilesDelivered() {
        XAPKFile[] xAPKFileArr;
        for (XAPKFile xf : this.xAPKS) {
            String fileName = Helpers.getExpansionAPKFileName(this, xf.mIsMain, xf.mFileVersion);
            if (!this.overrideExpansionName) {
                if (xf.mIsMain) {
                    this.expansionFileName = Helpers.generateSaveFileName(this, fileName);
                } else {
                    this.patchFileName = Helpers.generateSaveFileName(this, fileName);
                }
                System.out.println("download name " + (xf.mIsMain ? this.expansionFileName : this.patchFileName));
            }
            if (!Helpers.doesFileExist(this, fileName, xf.mFileSize, false)) {
                if (!this.FinalRelease) {
                    System.out.println("expansionFilesDelivered not exist " + fileName);
                }
                return false;
            }
        }
        return true;
    }

    private void initializeDownloadUI() {
        if (!this.FinalRelease) {
            System.out.println("initializeDownloadUI");
        }
        this.mDownloaderClientStub = DownloaderClientMarshaller.CreateStub(this, WarDownloaderService.class);
        this.mDownloaderClientStub.connect(this);
        this.downloadView = new SurfaceView(this);
        this.downloadHolder = this.downloadView.getHolder();
        this.downloadHolder.addCallback(new SurfaceHolder.Callback() { // from class: com.wardrumstudios.utils.WarMedia.5
            @Override // android.view.SurfaceHolder.Callback
            public final void surfaceCreated(SurfaceHolder holder) {
                WarMedia.this.downloadViewCreated = true;
            }

            @Override // android.view.SurfaceHolder.Callback
            public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
                if (!WarMedia.this.FinalRelease) {
                    System.out.println("surfaceChanged called - subViewSplash");
                }
            }

            @Override // android.view.SurfaceHolder.Callback
            public void surfaceDestroyed(SurfaceHolder holder) {
                if (!WarMedia.this.FinalRelease) {
                    System.out.println("surfaceDestroyed called - subViewSplash");
                }
            }
        });
        this.downloadHolder.setType(0);
        setContentView(this.downloadView);
        LinearLayout.LayoutParams myParams = new LinearLayout.LayoutParams(-2, -2);
        myParams.gravity = 17;
        int layoutID = Helpers.GetResourceIdentifier(getApplicationContext(), "download", "layout");
        LayoutInflater inflater = getLayoutInflater();
        LinearLayout tmpView = (LinearLayout) inflater.inflate(layoutID, (ViewGroup) null);
        addContentView(tmpView, myParams);
        int id = Helpers.GetResourceIdentifier(getApplicationContext(), "progressBar", "id");
        this.mPB = (ProgressBar) findViewById(id);
        int id2 = Helpers.GetResourceIdentifier(getApplicationContext(), "statusText", "id");
        this.mStatusText = (TextView) findViewById(id2);
        int id3 = Helpers.GetResourceIdentifier(getApplicationContext(), "progressAsFraction", "id");
        this.mProgressFraction = (TextView) findViewById(id3);
        int id4 = Helpers.GetResourceIdentifier(getApplicationContext(), "progressAsPercentage", "id");
        this.mProgressPercent = (TextView) findViewById(id4);
        int id5 = Helpers.GetResourceIdentifier(getApplicationContext(), "progressAverageSpeed", "id");
        this.mAverageSpeed = (TextView) findViewById(id5);
        int id6 = Helpers.GetResourceIdentifier(getApplicationContext(), "progressTimeRemaining", "id");
        this.mTimeRemaining = (TextView) findViewById(id6);
        int id7 = Helpers.GetResourceIdentifier(getApplicationContext(), "downloaderDashboard", "id");
        this.mDashboard = findViewById(id7);
        int id8 = Helpers.GetResourceIdentifier(getApplicationContext(), "approveCellular", "id");
        this.mCellMessage = findViewById(id8);
        int id9 = Helpers.GetResourceIdentifier(getApplicationContext(), "pauseButton", "id");
        this.mPauseButton = (Button) findViewById(id9);
        int id10 = Helpers.GetResourceIdentifier(getApplicationContext(), "wifiSettingsButton", "id");
        this.mWiFiSettingsButton = (Button) findViewById(id10);
        this.mPauseButton.setOnClickListener(new View.OnClickListener() { // from class: com.wardrumstudios.utils.WarMedia.6
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                try {
                    if (WarMedia.this.mStatePaused) {
                        WarMedia.this.mRemoteService.requestContinueDownload();
                    } else {
                        WarMedia.this.mRemoteService.requestPauseDownload();
                    }
                    WarMedia.this.setButtonPausedState(!WarMedia.this.mStatePaused);
                } catch (Exception e) {
                    System.out.println("mPauseButton error " + e.getMessage());
                }
            }
        });
        this.mWiFiSettingsButton.setOnClickListener(new View.OnClickListener() { // from class: com.wardrumstudios.utils.WarMedia.7
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
            }
        });
        int id11 = Helpers.GetResourceIdentifier(getApplicationContext(), "resumeOverCellular", "id");
        Button resumeOnCell = (Button) findViewById(id11);
        resumeOnCell.setOnClickListener(new View.OnClickListener() { // from class: com.wardrumstudios.utils.WarMedia.8
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                WarMedia.this.mRemoteService.setDownloadFlags(1);
                WarMedia.this.mRemoteService.requestContinueDownload();
                WarMedia.this.mCellMessage.setVisibility(8);
            }
        });
    }

    @Override // android.app.Activity, android.view.Window.Callback
    public void onWindowFocusChanged(boolean hasFocus) {
        if (this.ResumeEventDone && this.isUserPresent && this.viewIsActive && !this.IsScreenPaused && !this.paused) {
            if (this.GameIsFocused && !hasFocus) {
                pauseEvent();
            } else if (!this.GameIsFocused && hasFocus) {
                resumeEvent();
            }
            this.GameIsFocused = hasFocus;
        }
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            hideSystemUI();
        }
    }

    @Override // com.wardrumstudios.utils.WarGamepad, android.app.Activity, android.content.ComponentCallbacks
    public void onConfigurationChanged(Configuration newConfig) {
        if (this.DoLog) {
            System.out.println("Listener - onConfigurationChanged orient " + newConfig.orientation + " " + newConfig);
        }
        if (this.IsShowingKeyboard && newConfig.keyboard == 2 && 1 == newConfig.hardKeyboardHidden) {
            this.IsShowingKeyboard = false;
            imeClosed();
        }
        super.onConfigurationChanged(newConfig);
    }

    @Override // android.app.Activity, android.content.ComponentCallbacks
    public void onLowMemory() {
        lowMemoryEvent();
    }

    protected void NetworkChange() {
        int curNetwork;
        if (isWiFiAvailable()) {
            curNetwork = 2;
        } else {
            curNetwork = isNetworkAvailable() ? 1 : 0;
        }
        if (curNetwork != this.lastNetworkAvailable) {
            NativeNotifyNetworkChange(curNetwork);
            this.lastNetworkAvailable = curNetwork;
        }
    }

    @Override // android.app.Activity, android.view.Window.Callback
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        IntentFilter filter = new IntentFilter();
        filter.addAction("android.intent.action.SCREEN_OFF");
        filter.addAction("android.intent.action.USER_PRESENT");
        filter.addAction("android.net.conn.CONNECTIVITY_CHANGE");
        filter.addAction("android.intent.action.SCREEN_ON");
        if (this.DoLog) {
            System.out.println("registerReceiver");
        }
        registerReceiver(this.mReceiver, filter);
    }

    @Override // android.app.Activity, android.view.Window.Callback
    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        if (this.DoLog) {
            System.out.println("unregisterReceiver");
        }
        unregisterReceiver(this.mReceiver);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // com.wardrumstudios.utils.WarBase, com.nvidia.devtech.NvEventQueueActivity, android.app.Activity
    public void onResume() {
        if (this.DoLog) {
            System.out.println("WarMedia**** onResume viewIsActive " + this.viewIsActive + " isUserPresent " + this.isUserPresent);
        }
        super.onResume();
        for (int i = 0; i < MAX_GAME_PADS; i++) {
            if (this.GamePads[i].active && this.GamePads[i].mogaController != null) {
                this.GamePads[i].mogaController.onResume();
            }
        }
        while (!isExternalStorageReadable()) {
            System.out.println("Resuming when Media is not mounted, waiting for sdcard mount");
            mSleep(100L);
        }
        if (this.isUserPresent) {
            if (this.viewIsActive && this.ResumeEventDone) {
                resumeEvent();
                if (this.cachedSurfaceHolder != null) {
                    this.cachedSurfaceHolder.setKeepScreenOn(true);
                }
            }
            this.IsScreenPaused = false;
            PauseMoviePlayer(false);
        }
        this.paused = false;
    }

    void PauseMoviePlayer(final boolean bPause) {
        if (this.moviePlayer != null) {
            Runnable r = new Runnable() { // from class: com.wardrumstudios.utils.WarMedia.10
                @Override // java.lang.Runnable
                public void run() {
                    WarMedia.this.PauseMoviePlayerThread(bPause);
                }
            };
            new Thread(r).start();
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:44:0x0115, code lost:
        if (r6 > 5) goto L27;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    void PauseMoviePlayerThread(boolean bPause) {
        if (!this.skipMovies) {
            if (bPause) {
                try {
                    if (this.moviePlayer != null) {
                        if (this.moviePlayer.isPlaying()) {
                            try {
                                this.currentMovieMS = this.moviePlayer.getCurrentPosition();
                                this.moviePlayer.pause();
                                this.bMoviePlayerPaused = true;
                                System.out.println("moviePlayer paused at " + this.currentMovieMS);
                            } catch (Exception ex) {
                                System.out.println("moviePlayer pause failed " + ex.getMessage());
                                try {
                                    if (this.moviePlayer != null) {
                                        this.moviePlayer.release();
                                    }
                                } catch (Exception e) {
                                }
                                this.moviePlayer = null;
                                ClearVidView();
                                this.bMoviePlayerPaused = false;
                            }
                        } else {
                            System.out.println("moviePlayer not playing");
                            this.moviePlayer.release();
                            this.moviePlayer = null;
                            this.bMoviePlayerPaused = false;
                        }
                    }
                    return;
                } catch (IllegalStateException e2) {
                    System.out.println("PauseMoviePlayerThread err " + e2.getMessage());
                    ClearVidView();
                    this.moviePlayer = null;
                    this.bIsPlayingMovie = 0;
                    this.bMoviePlayerPaused = false;
                    return;
                }
            }
            System.out.println("moviePlayer resume bMoviePlayerPaused " + this.bMoviePlayerPaused + " moviePlayer " + this.moviePlayer);
            if (this.bMoviePlayerPaused && this.moviePlayer == null) {
                if (this.currentMovieLength > 0) {
                    PlayMovieInFile(this.currentMovieFilename, 1.0f, this.currentMovieOffset, this.currentMovieLength);
                } else {
                    PlayMovie(this.currentMovieFilename, 1.0f);
                }
                this.bMoviePlayerPaused = false;
            } else if (this.bMoviePlayerPaused && this.moviePlayer != null) {
                int count = 0;
                while (!IsMovieViewActive()) {
                    if (!this.FinalRelease) {
                        System.out.println("moviePlayer waiting for vidViewIsActive");
                    }
                    mSleep(100L);
                    count++;
                }
                try {
                    if (count <= 5) {
                        System.out.println("moviePlayer paused false");
                        if (this.currentMovieLength > 0) {
                            PlayMovieInFile(this.currentMovieFilename, 1.0f, this.currentMovieOffset, this.currentMovieLength, this.movieWindowHolder);
                        } else {
                            PlayMovie(this.currentMovieFilename, 1.0f);
                        }
                    } else {
                        this.moviePlayer.release();
                        this.moviePlayer = null;
                        ClearVidView();
                    }
                } catch (Exception ex2) {
                    System.out.println("moviePlayer resume failed " + ex2.getMessage());
                    this.moviePlayer = null;
                    ClearVidView();
                }
                this.bMoviePlayerPaused = false;
            }
        }
    }

    public void VibratePhone(int numMilliseconds) {
        if (!this.FinalRelease) {
            System.out.println("VibratePhone " + numMilliseconds);
        }
        if (this.myVib == null) {
            this.myVib = (Vibrator) getSystemService("vibrator");
        }
        if (this.myVib != null) {
            this.myVib.vibrate(numMilliseconds);
        }
    }

    public void VibratePhoneEffect(int effect) {
        if (!this.FinalRelease) {
            System.out.println("VibratePhoneEffect " + effect);
        }
        if (this.myVib == null) {
            this.myVib = (Vibrator) getSystemService("vibrator");
        }
        if (this.myVib != null) {
            this.myVib.vibrate(this.vibrateEffects[effect], -1);
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // com.wardrumstudios.utils.WarBase, com.nvidia.devtech.NvEventQueueActivity, android.app.Activity
    public void onPause() {
        if (this.DoLog) {
            System.out.println("Listener -  onPause");
        }
        if (this.cachedSurfaceHolder != null) {
            this.cachedSurfaceHolder.setKeepScreenOn(false);
        }
        for (int i = 0; i < MAX_GAME_PADS; i++) {
            if (this.GamePads[i].active && this.GamePads[i].mogaController != null) {
                this.GamePads[i].mogaController.onPause();
            }
        }
        super.onPause();
        PauseMoviePlayer(true);
        GetMemoryInfo(true);
        this.IsScreenPaused = true;
        this.paused = true;
    }

    @Override // com.wardrumstudios.utils.WarGamepad, com.nvidia.devtech.NvEventQueueActivity, android.app.Activity
    public boolean onTouchEvent(MotionEvent event) {
        if (this.MovieIsSkippable) {
            StopMovie();
        }
        if (this.DisplayMovieTextOnTap && this.movieTextViewIsActive) {
            this.movieTextDisplayNow = true;
            DrawMovieText();
        }
        if (this.IsShowingBackMessage == 2) {
            if (this.DoLog) {
                System.out.println("onTouchEvent exitDialog " + this.exitDialog);
            }
            if (this.exitDialog != null) {
                this.exitDialog.dismiss();
            }
            this.IsShowingBackMessage = 0;
            return true;
        }
        return super.onTouchEvent(event);
    }

    @Override // com.wardrumstudios.utils.WarGamepad, com.nvidia.devtech.NvEventQueueActivity, android.app.Activity, android.view.KeyEvent.Callback
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (this.AllowLongPressForExit && keyCode == 4 && !event.isAltPressed() && event.isLongPress()) {
            this.IsShowingBackMessage = 1;
            if (this.DoLog) {
                System.out.println("ShowExitDialog KeyDown");
            }
            ShowExitDialog();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    void ShowExitDialog() {
        this.handler.post(new Runnable() { // from class: com.wardrumstudios.utils.WarMedia.11
            @Override // java.lang.Runnable
            public void run() {
                WarMedia.this.exitDialog = new AlertDialog.Builder(this).setTitle("Press back again to exit").setOnKeyListener(new DialogInterface.OnKeyListener() { // from class: com.wardrumstudios.utils.WarMedia.11.1
                    @Override // android.content.DialogInterface.OnKeyListener
                    public boolean onKey(DialogInterface dlg, int KeyCode, KeyEvent event) {
                        if (WarMedia.this.DoLog) {
                            System.out.println("ShowExitDialog onKey action " + event.getAction() + " IsShowingBackMessage " + WarMedia.this.IsShowingBackMessage + " KeyCode " + KeyCode);
                        }
                        if (WarMedia.this.IsShowingBackMessage == 2) {
                            WarMedia.this.IsShowingBackMessage = 0;
                            if (KeyCode == 4) {
                                WarMedia.this.finish();
                            } else {
                                dlg.dismiss();
                            }
                        } else if (event.getAction() == 1) {
                            WarMedia.this.IsShowingBackMessage = 2;
                        }
                        return true;
                    }
                }).setCancelable(false).show();
                WarMedia.this.exitDialog.setCanceledOnTouchOutside(true);
            }
        });
    }

    public String getLocalIpAddress() {
        try {
            Enumeration<NetworkInterface> en = NetworkInterface.getNetworkInterfaces();
            while (en.hasMoreElements()) {
                NetworkInterface intf = en.nextElement();
                Enumeration<InetAddress> enumIpAddr = intf.getInetAddresses();
                while (enumIpAddr.hasMoreElements()) {
                    InetAddress inetAddress = enumIpAddr.nextElement();
                    if (!inetAddress.isLoopbackAddress()) {
                        return inetAddress.getHostAddress().toString();
                    }
                }
            }
        } catch (SocketException ex) {
            System.out.println("Got SocketException " + ex);
        }
        return null;
    }

    public String GetLocalIp() {
        return this.localIp;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // com.wardrumstudios.utils.WarBase, android.app.Activity
    public void onStart() {
        if (this.mDownloaderClientStub != null) {
            this.mDownloaderClientStub.connect(this);
        }
        super.onStart();
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // com.wardrumstudios.utils.WarBase, com.nvidia.devtech.NvEventQueueActivity, android.app.Activity
    public void onStop() {
        if (this.DoLog) {
            System.out.println("Listener - onStop");
        }
        if (this.mDownloaderClientStub != null) {
            this.mDownloaderClientStub.disconnect(this);
        }
        super.onStop();
    }

    @Override // com.nvidia.devtech.NvEventQueueActivity, android.app.Activity
    public void onRestart() {
        if (this.DoLog) {
            System.out.println("Listener - onRestart");
        }
        super.onRestart();
    }

    @Override // com.wardrumstudios.utils.WarGamepad, com.wardrumstudios.utils.WarBilling, com.wardrumstudios.utils.WarBase, com.nvidia.devtech.NvEventQueueActivity, android.app.Activity
    public void onDestroy() {
        if (this.DoLog) {
            System.out.println("Listener - onDestroy isFinishing " + isFinishing());
        }
        Process.killProcess(Process.myPid());
        super.onDestroy();
        Process.killProcess(Process.myPid());
    }

    @Override // android.app.Activity
    public void finish() {
        onDestroy();
        super.finish();
    }

    public void ExitGame() {
        onDestroy();
        finish();
        Process.killProcess(Process.myPid());
    }

    int GetSoundsIndex(String filename) {
        for (int i = 0; i < this.sounds.size(); i++) {
            PoolInfo pi = this.sounds.get(i);
            if (pi.filename.equals(filename)) {
                return pi.soundID;
            }
        }
        return -1;
    }

    public int GetMemoryInfo(boolean allProcesses) {
        if (this.mgr == null) {
            this.mgr = (ActivityManager) super.getSystemService("activity");
            this.memInfo = new ActivityManager.MemoryInfo();
        }
        this.mgr.getMemoryInfo(this.memInfo);
        this.memoryThreshold = (int) (this.memInfo.threshold / 1024);
        this.availableMemory = (int) ((this.memInfo.availMem / 1024) / 1024);
        if (Build.VERSION.SDK_INT >= 16) {
            this.totalMemory = (int) ((this.memInfo.totalMem / 1024) / 1024);
        } else {
            this.totalMemory = 256;
        }
        if (allProcesses) {
            this.mgr.getRunningAppProcesses();
            List<ActivityManager.RunningAppProcessInfo> l = this.mgr.getRunningAppProcesses();
            int[] pids = new int[l.size()];
            for (int i = 0; i < l.size(); i++) {
                pids[i] = l.get(i).pid;
            }
        } else if (this.myPid != null) {
            this.mgr.getProcessMemoryInfo(this.myPid);
        }
        return (int) ((this.memInfo.availMem / 1024) / 1024);
    }

    @Override // android.media.MediaPlayer.OnSeekCompleteListener
    public void onSeekComplete(MediaPlayer mp) {
        if (this.soundLog) {
            System.out.println("onSeekComplete");
        }
        if (mp == this.moviePlayer) {
            SetVideoAspect(mp);
            mp.start();
            mp.setOnSeekCompleteListener(null);
            this.bIsPlayingMovie = 2;
        }
    }

    /*  JADX ERROR: ArrayIndexOutOfBoundsException in pass: ۥ۟ۡۤ۟
        java.lang.ArrayIndexOutOfBoundsException: length=2; index=1345
        */
    void SetVideoAspect(android.media.MediaPlayer r12) {
        /*
            r11 = this;
            android.view.SurfaceView r8 = r11.customMovieSurface
            if (r8 == 0) goto L5
        L4:
            return
        L5:
            android.view.SurfaceView r8 = r11.vidView     // Catch: java.lang.IllegalStateException -> L50 java.lang.Exception -> L80
            int r5 = r8.getWidth()     // Catch: java.lang.IllegalStateException -> L50 java.lang.Exception -> L80
            android.view.SurfaceView r8 = r11.vidView     // Catch: java.lang.IllegalStateException -> L50 java.lang.Exception -> L80
            int r4 = r8.getHeight()     // Catch: java.lang.IllegalStateException -> L50 java.lang.Exception -> L80
            int r8 = r12.getVideoWidth()     // Catch: java.lang.IllegalStateException -> L50 java.lang.Exception -> L80
            float r7 = (float) r8     // Catch: java.lang.IllegalStateException -> L50 java.lang.Exception -> L80
            int r8 = r12.getVideoHeight()     // Catch: java.lang.IllegalStateException -> L50 java.lang.Exception -> L80
            float r6 = (float) r8     // Catch: java.lang.IllegalStateException -> L50 java.lang.Exception -> L80
            r8 = 1065353216(0x3f800000, float:1.0)
            int r8 = (r7 > r8 ? 1 : (r7 == r8 ? 0 : -1))
            if (r8 <= 0) goto L27
            r8 = 1092616192(0x41200000, float:10.0)
            int r8 = (r6 > r8 ? 1 : (r6 == r8 ? 0 : -1))
            if (r8 > 0) goto L52
        L27:
            java.io.PrintStream r8 = java.lang.System.out     // Catch: java.lang.IllegalStateException -> L50 java.lang.Exception -> L80
            java.lang.StringBuilder r9 = new java.lang.StringBuilder     // Catch: java.lang.IllegalStateException -> L50 java.lang.Exception -> L80
            r9.<init>()     // Catch: java.lang.IllegalStateException -> L50 java.lang.Exception -> L80
            java.lang.String r10 = "videosize error ("
            java.lang.StringBuilder r9 = r9.append(r10)     // Catch: java.lang.IllegalStateException -> L50 java.lang.Exception -> L80
            java.lang.StringBuilder r9 = r9.append(r7)     // Catch: java.lang.IllegalStateException -> L50 java.lang.Exception -> L80
            java.lang.String r10 = ","
            java.lang.StringBuilder r9 = r9.append(r10)     // Catch: java.lang.IllegalStateException -> L50 java.lang.Exception -> L80
            java.lang.StringBuilder r9 = r9.append(r6)     // Catch: java.lang.IllegalStateException -> L50 java.lang.Exception -> L80
            java.lang.String r10 = ")"
            java.lang.StringBuilder r9 = r9.append(r10)     // Catch: java.lang.IllegalStateException -> L50 java.lang.Exception -> L80
            java.lang.String r9 = r9.toString()     // Catch: java.lang.IllegalStateException -> L50 java.lang.Exception -> L80
            r8.println(r9)     // Catch: java.lang.IllegalStateException -> L50 java.lang.Exception -> L80
            goto L4
        L50:
            r8 = move-exception
            goto L4
        L52:
            float r8 = (float) r5     // Catch: java.lang.IllegalStateException -> L50 java.lang.Exception -> L80
            float r3 = r8 / r7
            float r8 = (float) r4     // Catch: java.lang.IllegalStateException -> L50 java.lang.Exception -> L80
            float r2 = r8 / r6
            float r0 = r7 / r6
            android.view.SurfaceView r8 = r11.customMovieSurface     // Catch: java.lang.IllegalStateException -> L50 java.lang.Exception -> L80
            if (r8 != 0) goto L82
            android.view.SurfaceView r8 = r11.vidView     // Catch: java.lang.IllegalStateException -> L50 java.lang.Exception -> L80
            android.view.ViewGroup$LayoutParams r1 = r8.getLayoutParams()     // Catch: java.lang.IllegalStateException -> L50 java.lang.Exception -> L80
            android.widget.FrameLayout$LayoutParams r1 = (android.widget.FrameLayout.LayoutParams) r1     // Catch: java.lang.IllegalStateException -> L50 java.lang.Exception -> L80
        L66:
            boolean r8 = r11.ForceSize     // Catch: java.lang.IllegalStateException -> L50 java.lang.Exception -> L80
            if (r8 == 0) goto L8b
            int r8 = r11.movieViewWidth     // Catch: java.lang.IllegalStateException -> L50 java.lang.Exception -> L80
            r1.width = r8     // Catch: java.lang.IllegalStateException -> L50 java.lang.Exception -> L80
            int r8 = r11.movieViewHeight     // Catch: java.lang.IllegalStateException -> L50 java.lang.Exception -> L80
            r1.height = r8     // Catch: java.lang.IllegalStateException -> L50 java.lang.Exception -> L80
        L72:
            r8 = 17
            r1.gravity = r8     // Catch: java.lang.IllegalStateException -> L50 java.lang.Exception -> L80
            android.view.SurfaceView r8 = r11.customMovieSurface     // Catch: java.lang.IllegalStateException -> L50 java.lang.Exception -> L80
            if (r8 != 0) goto La8
            android.view.SurfaceView r8 = r11.vidView     // Catch: java.lang.IllegalStateException -> L50 java.lang.Exception -> L80
            r8.setLayoutParams(r1)     // Catch: java.lang.IllegalStateException -> L50 java.lang.Exception -> L80
            goto L4
        L80:
            r8 = move-exception
            goto L4
        L82:
            android.view.SurfaceView r8 = r11.customMovieSurface     // Catch: java.lang.IllegalStateException -> L50 java.lang.Exception -> L80
            android.view.ViewGroup$LayoutParams r1 = r8.getLayoutParams()     // Catch: java.lang.IllegalStateException -> L50 java.lang.Exception -> L80
            android.widget.FrameLayout$LayoutParams r1 = (android.widget.FrameLayout.LayoutParams) r1     // Catch: java.lang.IllegalStateException -> L50 java.lang.Exception -> L80
            goto L66
        L8b:
            boolean r8 = r11.KeepAspectRatio     // Catch: java.lang.IllegalStateException -> L50 java.lang.Exception -> L80
            if (r8 == 0) goto La3
            int r8 = (r3 > r2 ? 1 : (r3 == r2 ? 0 : -1))
            if (r8 <= 0) goto L9b
            float r8 = (float) r4     // Catch: java.lang.IllegalStateException -> L50 java.lang.Exception -> L80
            float r8 = r8 * r0
            int r8 = (int) r8     // Catch: java.lang.IllegalStateException -> L50 java.lang.Exception -> L80
            r1.width = r8     // Catch: java.lang.IllegalStateException -> L50 java.lang.Exception -> L80
            r1.height = r4     // Catch: java.lang.IllegalStateException -> L50 java.lang.Exception -> L80
            goto L72
        L9b:
            r1.width = r5     // Catch: java.lang.IllegalStateException -> L50 java.lang.Exception -> L80
            float r8 = (float) r5     // Catch: java.lang.IllegalStateException -> L50 java.lang.Exception -> L80
            float r8 = r8 / r0
            int r8 = (int) r8     // Catch: java.lang.IllegalStateException -> L50 java.lang.Exception -> L80
            r1.height = r8     // Catch: java.lang.IllegalStateException -> L50 java.lang.Exception -> L80
            goto L72
        La3:
            r1.width = r5     // Catch: java.lang.IllegalStateException -> L50 java.lang.Exception -> L80
            r1.height = r4     // Catch: java.lang.IllegalStateException -> L50 java.lang.Exception -> L80
            goto L72
        La8:
            android.view.SurfaceView r8 = r11.customMovieSurface     // Catch: java.lang.IllegalStateException -> L50 java.lang.Exception -> L80
            r8.setLayoutParams(r1)     // Catch: java.lang.IllegalStateException -> L50 java.lang.Exception -> L80
            goto L4
        */
        throw new UnsupportedOperationException("Method not decompiled: com.wardrumstudios.utils.WarMedia.SetVideoAspect(android.media.MediaPlayer):void");
    }

    @Override // android.media.MediaPlayer.OnPreparedListener
    public void onPrepared(MediaPlayer mp) {
        if (mp.equals(this.moviePlayer)) {
            if (this.bIsPlayingMovie != 1) {
                System.out.println("trying to start a requested to stop movie");
                try {
                    mp.release();
                } catch (IllegalStateException e) {
                }
                this.moviePlayer = null;
                this.bIsPlayingMovie = 0;
                ClearVidView();
                return;
            }
            this.moviePlayer.setVolume(this.currentMovieVolume, this.currentMovieVolume);
            if (this.movieLooping != 0) {
                this.moviePlayer.setLooping(true);
            }
            if (this.currentMovieMS > 0) {
                mp.setOnSeekCompleteListener(this);
                mp.seekTo(this.currentMovieMS);
            } else {
                SetVideoAspect(mp);
                try {
                    mp.start();
                    this.bIsPlayingMovie = 2;
                } catch (IllegalStateException e2) {
                    System.out.println("onPrepared IllegalStateException " + e2.getMessage());
                    this.moviePlayer = null;
                    this.bIsPlayingMovie = 0;
                    ClearVidView();
                }
            }
            this.currentMovieMS = 0;
        }
    }

    @Override // android.media.MediaPlayer.OnCompletionListener
    public void onCompletion(MediaPlayer mp) {
        if (mp.equals(this.moviePlayer)) {
            System.out.println("onCompletion completed moviePlayer");
            this.moviePlayer = null;
            try {
                mp.release();
            } catch (IllegalStateException e) {
            }
            ClearVidView();
            if (this.bIsPlayingMovie == 2) {
                this.bIsPlayingMovie = 0;
            }
            this.lastMovieStop = System.currentTimeMillis() + 1000;
            this.MovieTextDisplayed = false;
            this.movieLooping = 0;
        }
    }

    @Override // android.media.MediaPlayer.OnErrorListener
    public boolean onError(MediaPlayer mp, int what, int extra) {
        System.out.println("onError what " + what + " exra " + extra);
        return true;
    }

    public boolean IsPhone() {
        return (getResources().getConfiguration().screenLayout & 15) < 3;
    }

    public void ClearSystemNotification() {
        runOnUiThread(new Runnable() { // from class: com.wardrumstudios.utils.WarMedia.12
            @Override // java.lang.Runnable
            public void run() {
                NotificationManager mNotificationManager = (NotificationManager) WarMedia.this.getSystemService("notification");
                mNotificationManager.cancelAll();
            }
        });
    }

    void SetVidView() {
        runOnUiThread(new Runnable() { // from class: com.wardrumstudios.utils.WarMedia.13
            @Override // java.lang.Runnable
            public void run() {
                if (WarMedia.this.customMovieSurface == null) {
                    if (!WarMedia.this.noVidSurface) {
                        WarMedia.this.vidView.setVisibility(0);
                        return;
                    }
                    return;
                }
                WarMedia.this.customMovieSurface.setVisibility(0);
            }
        });
    }

    public void ClearVidView() {
        runOnUiThread(new Runnable() { // from class: com.wardrumstudios.utils.WarMedia.14
            @Override // java.lang.Runnable
            public void run() {
                if (WarMedia.this.customMovieSurface == null) {
                    if (!WarMedia.this.noVidSurface) {
                        WarMedia.this.vidView.setVisibility(8);
                        return;
                    }
                    return;
                }
                WarMedia.this.customMovieSurface.setVisibility(8);
                WarMedia.this.movieView.setVisibility(8);
                WarMedia.this.customMovieSurface = null;
            }
        });
    }

    public boolean IsMovieViewActive() {
        return this.customMovieSurface == null ? this.vidViewIsActive : this.movieViewIsActive;
    }

    public void MovieSetSkippable(boolean skippable) {
        this.MovieIsSkippable = skippable;
    }

    public void StopMovie() {
        this.movieLooping = 0;
        this.MovieIsSkippable = false;
        this.MovieTextDisplayed = false;
        if (this.bIsPlayingMovie != 2) {
            if (this.DoLog) {
                System.out.println("MOVIE IS NOT PLAYING bIsPlayingMovie " + this.bIsPlayingMovie);
            }
            this.bIsPlayingMovie = 0;
        }
        try {
            if (this.moviePlayer != null) {
                this.moviePlayer.release();
                this.moviePlayer = null;
            }
        } catch (Exception e) {
            this.moviePlayer = null;
        }
        this.lastMovieStop = System.currentTimeMillis() + 1000;
        ClearVidView();
        this.bIsPlayingMovie = 0;
        this.bMoviePlayerPaused = false;
    }

    SurfaceHolder CreatTextSurface(SurfaceView surface) {
        SurfaceHolder holder = surface.getHolder();
        holder.addCallback(new SurfaceHolder.Callback() { // from class: com.wardrumstudios.utils.WarMedia.15
            @Override // android.view.SurfaceHolder.Callback
            public void surfaceCreated(SurfaceHolder holder2) {
                WarMedia.this.movieTextViewIsActive = true;
                Canvas canvas = WarMedia.this.movieTextHolder.lockCanvas();
                canvas.drawColor(0, PorterDuff.Mode.CLEAR);
                WarMedia.this.movieTextHolder.unlockCanvasAndPost(canvas);
                if (!WarMedia.this.movieViewCreated) {
                    System.out.println("movieTextSurface surfaceCreated firsttime");
                    WarMedia.this.movieTextViewCreated = true;
                    return;
                }
                System.out.println("movieTextSurface surfaceCreated");
            }

            @Override // android.view.SurfaceHolder.Callback
            public void surfaceChanged(SurfaceHolder holder2, int format, int width, int height) {
                System.out.println("movieTextSurface surfaceChanged width " + width + " height " + height);
            }

            @Override // android.view.SurfaceHolder.Callback
            public void surfaceDestroyed(SurfaceHolder holder2) {
                System.out.println("movieTextSurface surfaceDestroyed");
                WarMedia.this.movieTextViewIsActive = false;
            }
        });
        System.out.println("movieWindowHolder setType");
        holder.setType(0);
        surface.setZOrderOnTop(true);
        return holder;
    }

    TextView CreateTextView() {
        TextView tv = new TextView(this.activity);
        tv.setLayoutParams(new WindowManager.LayoutParams(-2, -2));
        tv.setTextSize(48.0f);
        tv.setText("Tap to Skip");
        return tv;
    }

    LinearLayout CreateMovieView(int x, int y, int width, int height) {
        LinearLayout ll = new LinearLayout(this.activity);
        ll.setOrientation(1);
        ll.setLayoutParams(new LinearLayout.LayoutParams(-2, -2));
        this.row1 = new LinearLayout(this.activity);
        this.row1.setOrientation(1);
        this.row1.setLayoutParams(new LinearLayout.LayoutParams(-2, y));
        ll.addView(this.row1);
        this.row2 = new LinearLayout(this.activity);
        this.row2.setOrientation(0);
        this.row2.setLayoutParams(new LinearLayout.LayoutParams(-2, height));
        this.col1 = new LinearLayout(this.activity);
        this.col1.setOrientation(0);
        this.col1.setLayoutParams(new LinearLayout.LayoutParams(x, -2));
        this.col2 = new LinearLayout(this.activity);
        this.col2.setOrientation(0);
        this.col2.setLayoutParams(new LinearLayout.LayoutParams(width, -2));
        this.movieWindowSurface = new SurfaceView(this.activity);
        this.col2.addView(this.movieWindowSurface);
        this.col3 = new LinearLayout(this.activity);
        this.col3.setOrientation(0);
        this.col3.setLayoutParams(new LinearLayout.LayoutParams(-2, -2));
        this.row2.addView(this.col1);
        this.row2.addView(this.col2);
        this.row2.addView(this.col3);
        ll.addView(this.row2);
        this.row3 = new LinearLayout(this.activity);
        this.row3.setOrientation(1);
        this.row3.setLayoutParams(new LinearLayout.LayoutParams(-2, -2));
        ll.addView(this.row3);
        return ll;
    }

    void ChangeMovieView(int x, int y, int width, int height) {
        this.row1.setLayoutParams(new LinearLayout.LayoutParams(-2, y));
        this.row2.setLayoutParams(new LinearLayout.LayoutParams(-2, height));
        this.col1.setLayoutParams(new LinearLayout.LayoutParams(x, -2));
        this.col2.setLayoutParams(new LinearLayout.LayoutParams(width, -2));
    }

    public void PlayMovieInWindow(final String inFilename, int x, int y, int width, int height, final float inVolume, final int inOffset, final int inLength, int looping, boolean forceSize) {
        System.out.println("PlayMovieInWindow filename " + inFilename + " movieWindowSurface " + this.movieWindowSurface + " inOffset " + inOffset + " inLength " + inLength);
        this.MovieIsSkippable = false;
        this.ForceSize = forceSize;
        System.out.println("PlayMovieInWindow ForceSize " + this.ForceSize + " width " + width + " height " + height);
        if (this.checkForMaxDisplaySize && this.baseDisplayHeight < (height * 2) / 3) {
            this.movieViewWidth = this.baseDisplayWidth;
            this.movieViewHeight = this.baseDisplayHeight;
            this.movieViewX = x;
            this.movieViewY = y;
        } else {
            this.movieViewWidth = width;
            this.movieViewHeight = height;
            this.movieViewX = x;
            this.movieViewY = y;
        }
        this.movieLooping = looping;
        this.bIsPlayingMovie = 1;
        runOnUiThread(new Runnable() { // from class: com.wardrumstudios.utils.WarMedia.16
            @Override // java.lang.Runnable
            public void run() {
                WarMedia.this.movieView = WarMedia.this.CreateMovieView(WarMedia.this.movieViewX, WarMedia.this.movieViewY, WarMedia.this.movieViewWidth, WarMedia.this.movieViewHeight);
                WarMedia.this.movieWindowHolder = WarMedia.this.movieWindowSurface.getHolder();
                WarMedia.this.movieWindowHolder.addCallback(new SurfaceHolder.Callback() { // from class: com.wardrumstudios.utils.WarMedia.16.1
                    @Override // android.view.SurfaceHolder.Callback
                    public void surfaceCreated(SurfaceHolder holder) {
                        WarMedia.this.movieViewIsActive = true;
                        if (!WarMedia.this.movieViewCreated) {
                            System.out.println("movieViewCreated surfaceCreated firsttime");
                            WarMedia.this.movieViewCreated = true;
                            return;
                        }
                        System.out.println("movieViewCreated surfaceCreated");
                    }

                    @Override // android.view.SurfaceHolder.Callback
                    public void surfaceChanged(SurfaceHolder holder, int format, int width2, int height2) {
                        System.out.println("movieView surfaceChanged width " + width2 + " height " + height2);
                        WarMedia.this.movieViewWidth = width2;
                        WarMedia.this.movieViewHeight = height2;
                    }

                    @Override // android.view.SurfaceHolder.Callback
                    public void surfaceDestroyed(SurfaceHolder holder) {
                        System.out.println("movieViewCreated surfaceDestroyed");
                        if (WarMedia.this.movieTextSurface != null) {
                            WarMedia.this.movieTextSurface.setVisibility(8);
                        }
                        WarMedia.this.movieViewIsActive = false;
                        WarMedia.this.movieIsStopping = false;
                        WarMedia.this.movieSubtitleText = "";
                        WarMedia.this.movieText = "";
                    }
                });
                System.out.println("movieWindowHolder setType");
                WarMedia.this.movieWindowHolder.setType(3);
                WarMedia.this.movieWindowSurface.setZOrderOnTop(true);
                WarMedia.this.movieWindowHolder.setFormat(-3);
                System.out.println("movieView (" + WarMedia.this.movieViewX + "," + WarMedia.this.movieViewY + ") (" + WarMedia.this.movieViewWidth + "," + WarMedia.this.movieViewHeight + ")");
                LinearLayout.LayoutParams myParams = new LinearLayout.LayoutParams(-2, -2);
                myParams.gravity = 17;
                WarMedia.this.addContentView(WarMedia.this.movieView, myParams);
                WarMedia.this.movieTextSurface = new SurfaceView(WarMedia.this.activity);
                WarMedia.this.movieTextHolder = WarMedia.this.CreatTextSurface(WarMedia.this.movieTextSurface);
                WarMedia.this.movieTextHolder.setFormat(-3);
                WarMedia.this.addContentView(WarMedia.this.movieTextSurface, new WindowManager.LayoutParams(-1, -1));
                System.out.println("PlayMovieInFile for inwindow");
                WarMedia.this.customMovieSurface = WarMedia.this.movieWindowSurface;
                Runnable r = new Runnable() { // from class: com.wardrumstudios.utils.WarMedia.16.2
                    @Override // java.lang.Runnable
                    public void run() {
                        int count = 0;
                        while (!WarMedia.this.movieViewIsActive) {
                            int count2 = count + 1;
                            if (count >= 10) {
                                break;
                            }
                            System.out.println("wait for create");
                            WarMedia.this.mSleep(1000L);
                            count = count2;
                        }
                        if (WarMedia.this.movieViewIsActive) {
                            if (inLength > 0) {
                                WarMedia.this.PlayMovieInFile(inFilename, inVolume, inOffset, inLength, WarMedia.this.movieWindowHolder);
                            } else {
                                WarMedia.this.PlayMovie(inFilename, inVolume, WarMedia.this.movieWindowHolder);
                            }
                        }
                    }
                };
                new Thread(r).start();
            }
        });
    }

    public void PlayMovieInFile(String filename, float volume, int offset, int length) {
        PlayMovieInFile(filename, volume, offset, length, this.vidHolder);
    }

    /*  JADX ERROR: ArrayIndexOutOfBoundsException in pass: ۥ۟ۡۤ۟
        java.lang.ArrayIndexOutOfBoundsException: length=2; index=1759
        */
    public void PlayMovieInFile(java.lang.String r9, float r10, int r11, int r12, android.view.SurfaceHolder r13) {
        /*
            r8 = this;
            android.view.SurfaceView r4 = r8.customMovieSurface
            if (r4 == 0) goto Ld
            android.view.SurfaceView r4 = r8.customMovieSurface
            android.view.SurfaceView r5 = r8.movieWindowSurface
            if (r4 == r5) goto Ld
            r4 = 0
            r8.customMovieSurface = r4
        Ld:
            r8.customMovieHolder = r13
            r4 = 1
            r8.bIsPlayingMovie = r4
            r4 = 0
            r8.bMoviePlayerPaused = r4
            r8.currentMovieFilename = r9
            r8.currentMovieOffset = r11
            r8.currentMovieLength = r12
            r8.currentMovieVolume = r10
            boolean r4 = r8.DoLog
            if (r4 == 0) goto L4d
            java.io.PrintStream r4 = java.lang.System.out
            java.lang.StringBuilder r5 = new java.lang.StringBuilder
            r5.<init>()
            java.lang.String r6 = "PlayMovieInFile "
            java.lang.StringBuilder r5 = r5.append(r6)
            java.lang.StringBuilder r5 = r5.append(r9)
            java.lang.String r6 = " offset "
            java.lang.StringBuilder r5 = r5.append(r6)
            java.lang.StringBuilder r5 = r5.append(r11)
            java.lang.String r6 = " length "
            java.lang.StringBuilder r5 = r5.append(r6)
            java.lang.StringBuilder r5 = r5.append(r12)
            java.lang.String r5 = r5.toString()
            r4.println(r5)
        L4d:
            java.lang.String r4 = "/"
            boolean r4 = r9.startsWith(r4)
            if (r4 == 0) goto Lc5
            java.lang.StringBuilder r4 = new java.lang.StringBuilder
            r4.<init>()
            java.io.File r5 = android.os.Environment.getExternalStorageDirectory()
            java.lang.String r5 = r5.getAbsolutePath()
            java.lang.StringBuilder r4 = r4.append(r5)
            java.lang.StringBuilder r4 = r4.append(r9)
            java.lang.String r3 = r4.toString()
        L6e:
            java.io.File r0 = new java.io.File
            r0.<init>(r3)
            boolean r4 = r0.exists()
            if (r4 != 0) goto L7a
            r3 = r9
        L7a:
            r2 = r3
            boolean r4 = r8.DoLog
            if (r4 == 0) goto Lab
            java.io.PrintStream r4 = java.lang.System.out
            java.lang.StringBuilder r5 = new java.lang.StringBuilder
            r5.<init>()
            java.lang.String r6 = "PlayMovieInFile "
            java.lang.StringBuilder r5 = r5.append(r6)
            java.lang.StringBuilder r5 = r5.append(r2)
            java.lang.String r6 = " offset "
            java.lang.StringBuilder r5 = r5.append(r6)
            java.lang.StringBuilder r5 = r5.append(r11)
            java.lang.String r6 = " length "
            java.lang.StringBuilder r5 = r5.append(r6)
            java.lang.StringBuilder r5 = r5.append(r12)
            java.lang.String r5 = r5.toString()
            r4.println(r5)
        Lab:
            r1 = r8
            android.media.MediaPlayer r4 = r8.moviePlayer     // Catch: java.lang.Exception -> Lf3
            if (r4 == 0) goto Lb5
            android.media.MediaPlayer r4 = r8.moviePlayer     // Catch: java.lang.Exception -> Lf3
            r4.release()     // Catch: java.lang.Exception -> Lf3
        Lb5:
            long r4 = r8.lastMovieStop
            long r6 = java.lang.System.currentTimeMillis()
            int r4 = (r4 > r6 ? 1 : (r4 == r6 ? 0 : -1))
            if (r4 <= 0) goto Le7
            r4 = 100
            r8.mSleep(r4)
            goto Lb5
        Lc5:
            java.lang.StringBuilder r4 = new java.lang.StringBuilder
            r4.<init>()
            java.lang.String r5 = r8.baseDirectory
            java.lang.StringBuilder r4 = r4.append(r5)
            java.lang.String r5 = "/"
            java.lang.StringBuilder r4 = r4.append(r5)
            java.lang.String r5 = "\\"
            java.lang.String r6 = "/"
            java.lang.String r5 = r9.replace(r5, r6)
            java.lang.StringBuilder r4 = r4.append(r5)
            java.lang.String r3 = r4.toString()
            goto L6e
        Le7:
            r8.SetVidView()
            com.wardrumstudios.utils.WarMedia$17 r4 = new com.wardrumstudios.utils.WarMedia$17
            r4.<init>()
            r8.runOnUiThread(r4)
            return
        Lf3:
            r4 = move-exception
            goto Lb5
        */
        throw new UnsupportedOperationException("Method not decompiled: com.wardrumstudios.utils.WarMedia.PlayMovieInFile(java.lang.String, float, int, int, android.view.SurfaceHolder):void");
    }

    public void PlayMovie(String filename, float Volume) {
        PlayMovie(filename, Volume, this.vidHolder);
    }

    /*  JADX ERROR: ArrayIndexOutOfBoundsException in pass: ۥ۟ۡۤ۟
        java.lang.ArrayIndexOutOfBoundsException: length=2; index=1841
        */
    public void PlayMovie(java.lang.String r13, float r14, android.view.SurfaceHolder r15) {
        /*
            Method dump skipped, instructions count: 297
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.wardrumstudios.utils.WarMedia.PlayMovie(java.lang.String, float, android.view.SurfaceHolder):void");
    }

    public int IsMoviePlaying() {
        if (this.bMoviePlayerPaused) {
            return 2;
        }
        if (this.bIsPlayingMovie == 1) {
            return this.bIsPlayingMovie;
        }
        if (this.bIsPlayingMovie != 2 || this.moviePlayer == null) {
            return 0;
        }
        try {
            if (this.moviePlayer.isPlaying()) {
                return this.bIsPlayingMovie;
            }
            return 0;
        } catch (IllegalStateException e) {
            return 0;
        }
    }

    public String GetConfigSetting(String key) {
        String value = getPreferences(0).getString(key, "");
        if (this.DoLog) {
            System.out.println("GetConfigSetting " + key + " value " + value);
        }
        return value;
    }

    public void SetConfigSetting(String key, String value) {
        SharedPreferences.Editor e = getPreferences(0).edit();
        e.putString(key, value);
        e.commit();
        if (this.DoLog) {
            System.out.println("SetConfigSetting " + key + " value " + value);
        }
    }

    public String OBFU_GetDeviceID() {
        TelephonyManager tm = (TelephonyManager) getBaseContext().getSystemService("phone");
        String tmDevice = "" + tm.getDeviceId();
        String tmSerial = "" + tm.getSimSerialNumber();
        String androidId = "" + Settings.Secure.getString(getContentResolver(), "android_id");
        UUID deviceUuid = new UUID(androidId.hashCode(), (tmDevice.hashCode() << 32) | tmSerial.hashCode());
        return deviceUuid.toString();
    }

    public void GetRealLocale() {
        Locale langLocal = Locale.getDefault();
        String lang = Locale.getDefault().getLanguage();
        String locale = Locale.getDefault().getDisplayLanguage();
        this.DeviceCountry = Locale.getDefault().getCountry();
        if (this.DoLog) {
            System.out.println("SetLocale getDefault " + lang + " langLocal " + langLocal + " locale " + locale + " DeviceCountry " + this.DeviceCountry);
        }
        this.DeviceLocale = lang;
    }

    public int GetDeviceLocale() {
        String lang = this.DeviceLocale;
        if (lang.equals("en")) {
            return 0;
        }
        if (lang.equals("fr")) {
            return 1;
        }
        if (lang.equals("de")) {
            return 2;
        }
        if (lang.equals("it")) {
            return 3;
        }
        if (lang.equals("es")) {
            return 4;
        }
        if (lang.equals("ja")) {
            return 5;
        }
        if (lang.equals("ko")) {
            return 6;
        }
        if (lang.equals("sv")) {
            return 7;
        }
        if (lang.equals("no") || lang.equals("nb") || lang.equals("nn")) {
            return 8;
        }
        return lang.equals("ru") ? 9 : 0;
    }

    public int GetLocale() {
        String lang = GetConfigSetting("currentLanguage");
        if (lang == "en") {
            return 0;
        }
        if (lang == "fr") {
            return 1;
        }
        if (lang == "de") {
            return 2;
        }
        if (lang == "it") {
            return 3;
        }
        if (lang == "es") {
            return 4;
        }
        if (lang == "ja") {
            return 5;
        }
        if (lang.equals("ko")) {
            return 6;
        }
        if (lang.equals("sv")) {
            return 7;
        }
        return (lang.equals("no") || lang.equals("nb") || lang.equals("nn")) ? 8 : 0;
    }

    /*  JADX ERROR: ArrayIndexOutOfBoundsException in pass: ۥ۟ۡۤ۟
        java.lang.ArrayIndexOutOfBoundsException: length=2; index=2013
        */
    public void SetLocale(java.lang.String r6) {
        /*
            r5 = this;
            r5.GetRealLocale()
            boolean r2 = r5.DoLog
            if (r2 == 0) goto L1f
            java.io.PrintStream r2 = java.lang.System.out
            java.lang.StringBuilder r3 = new java.lang.StringBuilder
            r3.<init>()
            java.lang.String r4 = "SetLocale "
            java.lang.StringBuilder r3 = r3.append(r4)
            java.lang.StringBuilder r3 = r3.append(r6)
            java.lang.String r3 = r3.toString()
            r2.println(r3)
        L1f:
            java.lang.String r2 = "currentLanguage"
            java.lang.String r1 = r5.GetConfigSetting(r2)
            boolean r2 = r5.DoLog
            if (r2 == 0) goto L41
            java.io.PrintStream r2 = java.lang.System.out
            java.lang.StringBuilder r3 = new java.lang.StringBuilder
            r3.<init>()
            java.lang.String r4 = "SetLocale oldlang "
            java.lang.StringBuilder r3 = r3.append(r4)
            java.lang.StringBuilder r3 = r3.append(r1)
            java.lang.String r3 = r3.toString()
            r2.println(r3)
        L41:
            java.lang.String r0 = ""
            java.lang.String r2 = "en"
            boolean r2 = r2.equals(r6)
            if (r2 == 0) goto L57
            java.lang.String r2 = r5.DeviceCountry
            java.lang.String r3 = "GB"
            boolean r2 = r2.equals(r3)
            if (r2 == 0) goto L69
            java.lang.String r0 = "GB"
        L57:
            java.util.Locale r2 = new java.util.Locale
            r2.<init>(r6, r0)
            r5.locale = r2
            java.util.Locale r2 = r5.locale
            java.util.Locale.setDefault(r2)
            java.lang.String r2 = "currentLanguage"
            r5.SetConfigSetting(r2, r6)
            return
        L69:
            java.lang.String r0 = "US"
            goto L57
        */
        throw new UnsupportedOperationException("Method not decompiled: com.wardrumstudios.utils.WarMedia.SetLocale(java.lang.String):void");
    }

    /*  JADX ERROR: ArrayIndexOutOfBoundsException in pass: ۥ۟ۡۤ۟
        java.lang.ArrayIndexOutOfBoundsException: length=2; index=2027
        */
    public void RestoreCurrentLanguage() {
        /*
            r4 = this;
            java.lang.String r2 = "currentLanguage"
            java.lang.String r1 = r4.GetConfigSetting(r2)
            java.lang.String r0 = ""
            java.lang.String r2 = ""
            boolean r2 = r2.equals(r1)
            if (r2 != 0) goto L30
            java.lang.String r2 = "en"
            boolean r2 = r2.equals(r1)
            if (r2 == 0) goto L24
            java.lang.String r2 = r4.DeviceCountry
            java.lang.String r3 = "GB"
            boolean r2 = r2.equals(r3)
            if (r2 == 0) goto L31
            java.lang.String r0 = "GB"
        L24:
            java.util.Locale r2 = new java.util.Locale
            r2.<init>(r1, r0)
            r4.locale = r2
            java.util.Locale r2 = r4.locale
            java.util.Locale.setDefault(r2)
        L30:
            return
        L31:
            java.lang.String r0 = "US"
            goto L24
        */
        throw new UnsupportedOperationException("Method not decompiled: com.wardrumstudios.utils.WarMedia.RestoreCurrentLanguage():void");
    }

    public void SetLocale(int newLang) {
        String lStr;
        switch (newLang) {
            case 0:
                lStr = "en";
                break;
            case 1:
                lStr = "fr";
                break;
            case 2:
                lStr = "de";
                break;
            case 3:
                lStr = "it";
                break;
            case 4:
                lStr = "es";
                break;
            case Constants.ActivityEvent.RESUME /* 5 */:
                lStr = "ja";
                break;
            case Constants.ActivityEvent.PAUSE /* 6 */:
                lStr = "ko";
                break;
            case Constants.ActivityEvent.SERVICE_CONNECTED /* 7 */:
                lStr = "sv";
                break;
            case WarGameService.CLIENT_DRIVE /* 8 */:
                lStr = "no";
                break;
            default:
                lStr = "en";
                break;
        }
        if (this.DoLog) {
            System.out.println("SetLocale " + newLang + " lStr " + lStr);
        }
        String lang = GetConfigSetting("currentLanguage");
        if (this.DoLog) {
            System.out.println("SetLocale oldlang " + lang);
        }
        this.locale = new Locale(lStr);
        Locale.setDefault(this.locale);
        SetConfigSetting("currentLanguage", lStr);
    }

    public boolean DeleteFile(String filename) {
        String fullFilename = this.baseDirectory + "/" + filename.replace('\\', '/');
        File delfile = new File(fullFilename);
        if (this.DoLog) {
            System.out.println("trying to delete file " + fullFilename);
        }
        if (delfile.exists()) {
            if (this.DoLog) {
                System.out.println("Deleting file " + fullFilename);
            }
            return delfile.delete();
        }
        return false;
    }

    public boolean FileRename(String oldfile, String newfile, int overWrite) {
        String oldFilename = this.baseDirectory + "/" + oldfile.replace('\\', '/');
        String newFilename = this.baseDirectory + "/" + newfile.replace('\\', '/');
        File oldFile = new File(oldFilename);
        File newFile = new File(newFilename);
        oldFile.renameTo(newFile);
        return true;
    }

    public String FileGetArchiveName(int type) {
        switch (type) {
            case 0:
                return this.apkFileName;
            case 1:
                return this.expansionFileName;
            case 2:
                return this.patchFileName;
            default:
                return "";
        }
    }

    public boolean IsTV() {
        return this.IsAndroidTV;
    }

    public String GetAndroidBuildinfo(int index) {
        switch (index) {
            case 0:
                return Build.MANUFACTURER;
            case 1:
                return Build.PRODUCT;
            case 2:
                return Build.MODEL;
            case 3:
                return Build.HARDWARE;
            default:
                return "UNKNOWN";
        }
    }

    public int GetDeviceInfo(int index) {
        switch (index) {
            case 0:
                return getNumberOfProcessors();
            case 1:
                return this.hasTouchScreen ? 1 : 0;
            default:
                return -1;
        }
    }

    public int GetDeviceType() {
        System.out.println("Build info version device  " + Build.DEVICE);
        System.out.println("Build MANUFACTURER  " + Build.MANUFACTURER);
        System.out.println("Build BOARD  " + Build.BOARD);
        System.out.println("Build DISPLAY  " + Build.DISPLAY);
        System.out.println("Build CPU_ABI  " + Build.CPU_ABI);
        System.out.println("Build CPU_ABI2  " + Build.CPU_ABI2);
        System.out.println("Build HARDWARE  " + Build.HARDWARE);
        System.out.println("Build MODEL  " + Build.MODEL);
        System.out.println("Build PRODUCT  " + Build.PRODUCT);
        int isTegra = this.glVendor.contains("NVIDIA") ? 2 : 0;
        int numProcs = getNumberOfProcessors() * 4;
        int mem = this.availableMemory * 64;
        int ret = (this.isPhone ? 1 : 0) + isTegra + numProcs + mem;
        if (!this.FinalRelease) {
            System.out.println("renderer '" + this.glVendor + "' ret=" + ret);
        }
        return ret;
    }

    private int getNumberOfProcessors() {
        try {
            File dir = new File("/sys/devices/system/cpu/");
            File[] files = dir.listFiles(new FileFilter() { // from class: com.wardrumstudios.utils.WarMedia.1CpuFilter
                @Override // java.io.FileFilter
                public boolean accept(File pathname) {
                    return Pattern.matches("cpu[0-9]", pathname.getName());
                }
            });
            return files.length;
        } catch (Exception e) {
            return 1;
        }
    }

    public void ShowKeyboard(int show) {
        if (getResources().getConfiguration().hardKeyboardHidden != 1) {
            InputMethodManager myImm = (InputMethodManager) getSystemService("input_method");
            if (show != 0) {
                myImm.toggleSoftInput(2, 0);
                this.IsShowingKeyboard = true;
                return;
            }
            View tbview = getCurrentFocus();
            if (tbview != null) {
                InputMethodManager imm = (InputMethodManager) getSystemService("input_method");
                imm.hideSoftInputFromWindow(tbview.getWindowToken(), 0);
            }
            myImm.toggleSoftInput(0, 0);
            this.IsShowingKeyboard = false;
            System.out.println("hideSystemUI");
            hideSystemUI();
        }
    }

    public boolean IsKeyboardShown() {
        return this.IsShowingKeyboard;
    }

    private void setState(int newState) {
        if (this.mState != newState) {
            this.mState = newState;
            this.mStatusText.setText(Helpers.getDownloaderStringResourceIDFromState(getApplicationContext(), newState));
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void setButtonPausedState(boolean paused) {
        this.mStatePaused = paused;
        int stringResourceID = paused ? Helpers.GetResourceIdentifier(getApplicationContext(), "text_button_resume", "string") : Helpers.GetResourceIdentifier(getApplicationContext(), "text_button_pause", "string");
        this.mPauseButton.setText(stringResourceID);
    }

    public void onServiceConnected(Messenger m) {
        this.mRemoteService = DownloaderServiceMarshaller.CreateProxy(m);
        this.mRemoteService.onClientUpdated(this.mDownloaderClientStub.getMessenger());
    }

    public void onDownloadStateChanged(int newState) {
        boolean paused;
        boolean indeterminate;
        setState(newState);
        boolean showDashboard = true;
        boolean showCellMessage = false;
        switch (newState) {
            case 1:
                paused = false;
                indeterminate = true;
                break;
            case 2:
            case 3:
                showDashboard = true;
                paused = false;
                indeterminate = true;
                break;
            case 4:
                paused = false;
                showDashboard = true;
                indeterminate = false;
                break;
            case Constants.ActivityEvent.RESUME /* 5 */:
                if (expansionFilesDelivered()) {
                    validateXAPKZipFiles();
                    return;
                }
                return;
            case Constants.ActivityEvent.PAUSE /* 6 */:
            case 10:
            case 11:
            case 13:
            case 17:
            default:
                paused = true;
                indeterminate = true;
                showDashboard = true;
                break;
            case Constants.ActivityEvent.SERVICE_CONNECTED /* 7 */:
                paused = true;
                indeterminate = false;
                break;
            case WarGameService.CLIENT_DRIVE /* 8 */:
            case 9:
                showDashboard = false;
                paused = true;
                indeterminate = false;
                showCellMessage = true;
                break;
            case 12:
            case 14:
                paused = true;
                indeterminate = false;
                break;
            case WarGameService.CLIENT_ALL /* 15 */:
            case 16:
            case 18:
            case 19:
                paused = true;
                showDashboard = true;
                indeterminate = false;
                break;
        }
        int newDashboardVisibility = showDashboard ? 0 : 8;
        if (this.mDashboard.getVisibility() != newDashboardVisibility) {
            this.mDashboard.setVisibility(newDashboardVisibility);
        }
        int cellMessageVisibility = showCellMessage ? 0 : 8;
        if (this.mCellMessage.getVisibility() != cellMessageVisibility) {
            this.mCellMessage.setVisibility(cellMessageVisibility);
        }
        this.mPB.setIndeterminate(indeterminate);
        setButtonPausedState(paused);
    }

    void validateXAPKZipFiles() {
        System.out.println("validateXAPKZipFiles IsInValidation " + this.IsInValidation);
        if (!this.IsInValidation) {
            this.IsInValidation = true;
            AsyncTask<Object, DownloadProgressInfo, Boolean> validationTask = new AsyncTask<Object, DownloadProgressInfo, Boolean>() { // from class: com.wardrumstudios.utils.WarMedia.19
                @Override // android.os.AsyncTask
                protected void onPreExecute() {
                    WarMedia.this.mDashboard.setVisibility(0);
                    WarMedia.this.mCellMessage.setVisibility(8);
                    WarMedia.this.mStatusText.setText(Helpers.GetResourceIdentifier(WarMedia.this.getApplicationContext(), "text_verifying_download", "string"));
                    WarMedia.this.mPauseButton.setOnClickListener(new View.OnClickListener() { // from class: com.wardrumstudios.utils.WarMedia.19.1
                        @Override // android.view.View.OnClickListener
                        public void onClick(View view) {
                            WarMedia.this.mCancelValidation = true;
                        }
                    });
                    WarMedia.this.mPauseButton.setText(Helpers.GetResourceIdentifier(WarMedia.this.getApplicationContext(), "text_button_cancel_verify", "string"));
                    super.onPreExecute();
                }

                /* JADX INFO: Access modifiers changed from: protected */
                /* JADX WARN: Can't rename method to resolve collision */
                @Override // android.os.AsyncTask
                public Boolean doInBackground(Object... params) {
                    XAPKFile[] xAPKFileArr;
                    for (XAPKFile xf : WarMedia.this.xAPKS) {
                        String fileName = Helpers.getExpansionAPKFileName(WarMedia.this, xf.mIsMain, xf.mFileVersion);
                        System.out.println("Verify " + fileName);
                        if (!Helpers.doesFileExist(WarMedia.this, fileName, xf.mFileSize, false)) {
                            return false;
                        }
                        if (xf.mIsMain) {
                            WarMedia.this.expansionFileName = Helpers.generateSaveFileName(WarMedia.this, fileName);
                        } else {
                            WarMedia.this.patchFileName = Helpers.generateSaveFileName(WarMedia.this, fileName);
                        }
                    }
                    return true;
                }

                /* JADX INFO: Access modifiers changed from: protected */
                @Override // android.os.AsyncTask
                public void onProgressUpdate(DownloadProgressInfo... values) {
                    WarMedia.this.onDownloadProgress(values[0]);
                    super.onProgressUpdate((Object[]) values);
                }

                /* JADX INFO: Access modifiers changed from: protected */
                @Override // android.os.AsyncTask
                public void onPostExecute(Boolean result) {
                    System.out.println("onPostExecute result " + result);
                    if (result.booleanValue()) {
                        WarMedia.this.mDashboard.setVisibility(8);
                        WarMedia.this.mCellMessage.setVisibility(8);
                        WarMedia.this.downloadView.setVisibility(8);
                        if (WarMedia.this.view.getParent() != null) {
                            WarMedia.this.setContentView((View) WarMedia.this.view.getParent());
                        } else {
                            WarMedia.this.setContentView(WarMedia.this.view);
                        }
                        WarMedia.this.AfterDownloadFunction();
                    } else {
                        WarMedia.this.mDashboard.setVisibility(0);
                        WarMedia.this.mCellMessage.setVisibility(8);
                        WarMedia.this.mStatusText.setText(Helpers.GetResourceIdentifier(WarMedia.this.getApplicationContext(), "text_validation_failed", "string"));
                        WarMedia.this.mPauseButton.setOnClickListener(new View.OnClickListener() { // from class: com.wardrumstudios.utils.WarMedia.19.2
                            @Override // android.view.View.OnClickListener
                            public void onClick(View view) {
                                WarMedia.this.finish();
                            }
                        });
                        WarMedia.this.mPauseButton.setText(17039360);
                    }
                    super.onPostExecute((AnonymousClass19) result);
                }
            };
            validationTask.execute(new Object());
        }
    }

    public void onDownloadProgress(DownloadProgressInfo progress) {
        String downloadSpeed = "" + Helpers.getSpeedString(progress.mCurrentSpeed) + " KB/s";
        this.mAverageSpeed.setText(downloadSpeed);
        String timeRemaining = "" + Helpers.getTimeRemaining(progress.mTimeRemaining) + " seconds";
        this.mTimeRemaining.setText(timeRemaining);
        progress.mOverallTotal = progress.mOverallTotal;
        this.mPB.setMax((int) (progress.mOverallTotal >> 8));
        this.mPB.setProgress((int) (progress.mOverallProgress >> 8));
        this.mProgressPercent.setText(Long.toString((progress.mOverallProgress * 100) / progress.mOverallTotal) + "%");
        this.mProgressFraction.setText(Helpers.getDownloadProgressString(progress.mOverallProgress, progress.mOverallTotal));
    }

    public String GetPackageName(String appname) {
        PackageManager pm = getPackageManager();
        List<ApplicationInfo> appinfo = pm.getInstalledApplications(8192);
        for (int i = 0; i < appinfo.size(); i++) {
            if (appname.compareToIgnoreCase(appinfo.get(i).packageName.toString()) == 0) {
                return appinfo.get(i).sourceDir;
            }
        }
        return "";
    }

    public boolean IsAppInstalled(String appname) {
        PackageManager pm = getPackageManager();
        List<ApplicationInfo> appinfo = pm.getInstalledApplications(8192);
        for (int i = 0; i < appinfo.size(); i++) {
            System.out.println("app[" + i + "]=" + appinfo.get(i).packageName + " dir " + appinfo.get(i).sourceDir);
            if (appname.compareToIgnoreCase(appinfo.get(i).packageName.toString()) == 0) {
                return true;
            }
        }
        return false;
    }

    void OpenLink(String link) {
        Intent browserIntent = new Intent("android.intent.action.VIEW", Uri.parse(link));
        startActivity(browserIntent);
    }

    public boolean IsCloudAvailable() {
        return false;
    }

    public void LoadAllGamesFromCloud() {
    }

    public String LoadGameFromCloud(int slot, byte[] array) {
        return "";
    }

    public void SaveGameToCloud(int slot, byte[] array, int numbytes) {
    }

    public boolean NewCloudSaveAvailable(int slot) {
        return false;
    }

    public void MovieKeepAspectRatio(boolean keep) {
        this.KeepAspectRatio = keep;
    }

    void ClearMovieText() {
        runOnUiThread(new Runnable() { // from class: com.wardrumstudios.utils.WarMedia.20
            @Override // java.lang.Runnable
            public void run() {
                Canvas canvas = WarMedia.this.movieTextHolder.lockCanvas();
                canvas.drawColor(0, PorterDuff.Mode.CLEAR);
                WarMedia.this.movieTextHolder.unlockCanvasAndPost(canvas);
            }
        });
    }

    void MovieSetTextScale(int scale) {
        this.movieTextScale = scale;
        SetPaint(-16711936, this.movieTextScale);
    }

    void SetPaint(int color, int size) {
        this.mTextPaint = new Paint();
        this.mTextPaint.setAntiAlias(true);
        this.mTextPaint.setTextSize(size);
        this.mTextPaint.setColor(color);
        this.mAscent = (int) this.mTextPaint.ascent();
        this.tPaint = new Paint();
        this.tPaint.setColor(-65536);
        this.textPaint = new TextPaint();
        this.textPaint.setColor(-1);
        this.textPaint.setTextSize(this.movieTextScale);
        this.sTextPaint = new TextPaint();
        this.sTextPaint.setColor(-16777216);
        this.sTextPaint.setTextSize(this.movieTextScale);
    }

    void DrawMovieText() {
        runOnUiThread(new Runnable() { // from class: com.wardrumstudios.utils.WarMedia.21
            /*  JADX ERROR: ArrayIndexOutOfBoundsException in pass: ۥ۟ۡۤ۟
                java.lang.ArrayIndexOutOfBoundsException: length=2; index=2557
                */
            @Override // java.lang.Runnable
            public void run() {
                /*
                    r12 = this;
                    r11 = 1
                    com.wardrumstudios.utils.WarMedia r3 = com.wardrumstudios.utils.WarMedia.this
                    java.lang.String r3 = com.wardrumstudios.utils.WarMedia.access$2300(r3)
                    int r3 = r3.length()
                    if (r3 > 0) goto L17
                    com.wardrumstudios.utils.WarMedia r3 = com.wardrumstudios.utils.WarMedia.this
                    java.lang.String r3 = r3.movieSubtitleText
                    int r3 = r3.length()
                    if (r3 <= 0) goto Laf
                L17:
                    r11 = 0
                    com.wardrumstudios.utils.WarMedia r3 = com.wardrumstudios.utils.WarMedia.this
                    android.view.SurfaceView r3 = r3.movieTextSurface
                    r4 = 0
                    r3.setVisibility(r4)
                    java.lang.StringBuilder r3 = new java.lang.StringBuilder
                    r3.<init>()
                    com.wardrumstudios.utils.WarMedia r4 = com.wardrumstudios.utils.WarMedia.this
                    java.lang.String r4 = r4.movieSubtitleText
                    java.lang.StringBuilder r3 = r3.append(r4)
                    java.lang.String r4 = "\n\n"
                    java.lang.StringBuilder r4 = r3.append(r4)
                    com.wardrumstudios.utils.WarMedia r3 = com.wardrumstudios.utils.WarMedia.this
                    boolean r3 = r3.movieTextDisplayNow
                    if (r3 == 0) goto Ld2
                    com.wardrumstudios.utils.WarMedia r3 = com.wardrumstudios.utils.WarMedia.this
                    java.lang.String r3 = com.wardrumstudios.utils.WarMedia.access$2400(r3)
                L3f:
                    java.lang.StringBuilder r3 = r4.append(r3)
                    java.lang.String r1 = r3.toString()
                    com.wardrumstudios.utils.WarMedia r3 = com.wardrumstudios.utils.WarMedia.this
                    android.view.SurfaceHolder r3 = r3.movieTextHolder
                    android.graphics.Canvas r10 = r3.lockCanvas()
                    if (r10 == 0) goto Laf
                    android.text.StaticLayout r0 = new android.text.StaticLayout
                    com.wardrumstudios.utils.WarMedia r3 = com.wardrumstudios.utils.WarMedia.this
                    android.text.TextPaint r2 = r3.textPaint
                    com.wardrumstudios.utils.WarMedia r3 = com.wardrumstudios.utils.WarMedia.this
                    int r3 = com.wardrumstudios.utils.WarMedia.access$2500(r3)
                    int r3 = r3 + (-100)
                    android.text.Layout$Alignment r4 = android.text.Layout.Alignment.ALIGN_CENTER
                    r5 = 1065353216(0x3f800000, float:1.0)
                    r6 = 1065353216(0x3f800000, float:1.0)
                    r7 = 1
                    r0.<init>(r1, r2, r3, r4, r5, r6, r7)
                    android.text.StaticLayout r2 = new android.text.StaticLayout
                    com.wardrumstudios.utils.WarMedia r3 = com.wardrumstudios.utils.WarMedia.this
                    android.text.TextPaint r4 = r3.sTextPaint
                    com.wardrumstudios.utils.WarMedia r3 = com.wardrumstudios.utils.WarMedia.this
                    int r3 = com.wardrumstudios.utils.WarMedia.access$2600(r3)
                    int r5 = r3 + (-100)
                    android.text.Layout$Alignment r6 = android.text.Layout.Alignment.ALIGN_CENTER
                    r7 = 1065353216(0x3f800000, float:1.0)
                    r8 = 1065353216(0x3f800000, float:1.0)
                    r9 = 1
                    r3 = r1
                    r2.<init>(r3, r4, r5, r6, r7, r8, r9)
                    r3 = 0
                    android.graphics.PorterDuff$Mode r4 = android.graphics.PorterDuff.Mode.CLEAR
                    r10.drawColor(r3, r4)
                    r3 = 1112539136(0x42500000, float:52.0)
                    com.wardrumstudios.utils.WarMedia r4 = com.wardrumstudios.utils.WarMedia.this
                    int r4 = com.wardrumstudios.utils.WarMedia.access$2700(r4)
                    int r5 = r2.getHeight()
                    int r4 = r4 - r5
                    int r4 = r4 + (-5)
                    float r4 = (float) r4
                    r10.translate(r3, r4)
                    r2.draw(r10)
                    r3 = -1073741824(0xffffffffc0000000, float:-2.0)
                    r4 = -1073741824(0xffffffffc0000000, float:-2.0)
                    r10.translate(r3, r4)
                    r0.draw(r10)
                    com.wardrumstudios.utils.WarMedia r3 = com.wardrumstudios.utils.WarMedia.this
                    android.view.SurfaceHolder r3 = r3.movieTextHolder
                    r3.unlockCanvasAndPost(r10)
                Laf:
                    if (r11 == 0) goto Ld1
                    com.wardrumstudios.utils.WarMedia r3 = com.wardrumstudios.utils.WarMedia.this
                    android.view.SurfaceHolder r3 = r3.movieTextHolder
                    android.graphics.Canvas r10 = r3.lockCanvas()
                    if (r10 == 0) goto Lc8
                    r3 = 0
                    android.graphics.PorterDuff$Mode r4 = android.graphics.PorterDuff.Mode.CLEAR
                    r10.drawColor(r3, r4)
                    com.wardrumstudios.utils.WarMedia r3 = com.wardrumstudios.utils.WarMedia.this
                    android.view.SurfaceHolder r3 = r3.movieTextHolder
                    r3.unlockCanvasAndPost(r10)
                Lc8:
                    com.wardrumstudios.utils.WarMedia r3 = com.wardrumstudios.utils.WarMedia.this
                    android.view.SurfaceView r3 = r3.movieTextSurface
                    r4 = 8
                    r3.setVisibility(r4)
                Ld1:
                    return
                Ld2:
                    java.lang.String r3 = ""
                    goto L3f
                */
                throw new UnsupportedOperationException("Method not decompiled: com.wardrumstudios.utils.WarMedia.AnonymousClass21.run():void");
            }
        });
    }

    void DisplayMovieText() {
        System.out.println("DisplayMovieText vidViewIsActive " + this.vidViewIsActive);
        DrawMovieText();
    }

    public void MovieClearText(boolean isSubtitle) {
        if (isSubtitle) {
            this.movieSubtitleText = "";
        } else {
            this.movieText = "";
        }
        DrawMovieText();
    }

    public void MovieSetText(String text, boolean DisplayNow, boolean isSubtitle) {
        if (isSubtitle) {
            this.movieSubtitleText = text;
        } else {
            this.DisplayMovieTextOnTap = !DisplayNow;
            this.movieTextDisplayNow = DisplayNow;
            this.movieText = text;
        }
        if (DisplayNow) {
            DisplayMovieText();
        } else if (!DisplayNow) {
            runOnUiThread(new Runnable() { // from class: com.wardrumstudios.utils.WarMedia.22
                @Override // java.lang.Runnable
                public void run() {
                    System.out.println("MovieSetText create surface");
                    WarMedia.this.movieTextSurface.setVisibility(0);
                }
            });
        }
    }

    public void MovieDisplayText(boolean display) {
        System.out.println("MovieDisplayText " + display);
        if (display && !this.MovieTextDisplayed) {
            DisplayMovieText();
        }
    }

    public void DisplaySplashScreen(final String splashPng, final int splashTimer) {
        runOnUiThread(new Runnable() { // from class: com.wardrumstudios.utils.WarMedia.23
            @Override // java.lang.Runnable
            public void run() {
                try {
                    WarMedia.this.handler.postDelayed(new Runnable() { // from class: com.wardrumstudios.utils.WarMedia.23.1
                        @Override // java.lang.Runnable
                        public void run() {
                            WarMedia.this.ClearSplashScreen();
                        }
                    }, splashTimer);
                    ImageView splashView = new ImageView(WarMedia.this.getApplicationContext());
                    WarMedia.this.llSplashView = new LinearLayout(WarMedia.this.getApplicationContext());
                    Drawable dr = Drawable.createFromStream(WarMedia.this.getAssets().open(splashPng), null);
                    int width = dr.getIntrinsicWidth() - 40;
                    int height = dr.getIntrinsicHeight() - 40;
                    splashView.setImageDrawable(dr);
                    int surfaceView_Width = WarMedia.this.baseDisplayWidth;
                    int surfaceView_Height = WarMedia.this.baseDisplayHeight;
                    LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(100, 100);
                    float ratio_width = surfaceView_Width / width;
                    float ratio_height = surfaceView_Height / height;
                    float aspectratio = width / height;
                    if (ratio_width > ratio_height) {
                        layoutParams.width = (int) (surfaceView_Height * aspectratio);
                        layoutParams.height = surfaceView_Height;
                    } else {
                        layoutParams.width = surfaceView_Width;
                        layoutParams.height = (int) (surfaceView_Width / aspectratio);
                    }
                    int i = (surfaceView_Width - layoutParams.width) / 2;
                    int i2 = (surfaceView_Height - layoutParams.height) / 2;
                    layoutParams.gravity = 17;
                    WarMedia.this.llSplashView.addView(splashView, layoutParams);
                    LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(-1, -1);
                    layoutParams2.gravity = 17;
                    WarMedia.this.addContentView(WarMedia.this.llSplashView, layoutParams2);
                } catch (Exception e) {
                    WarMedia.this.llSplashView = null;
                    System.out.println("DisplaySplashScreeen Error");
                }
            }
        });
    }

    void ClearSplashScreen() {
        runOnUiThread(new Runnable() { // from class: com.wardrumstudios.utils.WarMedia.24
            @Override // java.lang.Runnable
            public void run() {
                if (WarMedia.this.DoLog) {
                    System.out.println("Clearing SplashScreen ");
                }
                if (WarMedia.this.llSplashView != null) {
                    WarMedia.this.llSplashView.setVisibility(8);
                }
                WarMedia.this.llSplashView = null;
            }
        });
    }

    public int GetSpecialBuildType() {
        return this.SpecialBuildType;
    }

    public void DeleteDirectory(String dirString, boolean recurse) {
        File dir = new File(dirString);
        if (dir.isDirectory()) {
            String[] children = dir.list();
            for (int i = 0; i < children.length; i++) {
                File child = new File(dir, children[i]);
                if (child.isDirectory()) {
                    DeleteDirectory(dir + "/" + children[i], recurse);
                }
                System.out.println("delete " + dir + "/" + children[i]);
                child.delete();
            }
            dir.delete();
        }
    }

    public boolean CustomLoadFunction() {
        return false;
    }

    public void AfterDownloadFunction() {
        DoResumeEvent();
    }

    public void SendStatEvent(String eventId, boolean timedEvent) {
    }

    public void SendTimedStatEventEnd(String eventId) {
    }

    public void SendStatEvent(String eventId, String paramName, String paramValue, boolean timedEvent) {
    }

    public int GetTotalMemory() {
        return this.totalMemory;
    }

    public float GetScreenWidthInches() {
        return this.screenWidthInches;
    }

    public int GetLowThreshhold() {
        return this.memoryThreshold;
    }

    public int GetAvailableMemory() {
        try {
            Runtime info = Runtime.getRuntime();
            int freeSize = (int) ((info.freeMemory() / 1024) / 1024);
            long totalSize = info.totalMemory();
            long usedSize = totalSize - freeSize;
        } catch (Exception e) {
            e.printStackTrace();
        }
        GetMemoryInfo(false);
        return this.availableMemory;
    }

    public String GetAppId() {
        return getPackageName();
    }

    public void ScreenSetWakeLock(boolean enable) {
        if (!enable) {
            this.myWakeLock.release();
        } else {
            this.myWakeLock.acquire();
        }
    }

    public void CreateTextBox(int id, int x, int y, int x2, int y2) {
    }

    @Override // android.app.Activity
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        System.out.println("onRequestPermissionsResult");
        switch (requestCode) {
            case REQUEST_READ_EXTERNAL_STORAGE /* 8001 */:
                if (grantResults.length > 0 && grantResults[0] == 0) {
                    this.waitForPermissions = false;
                    localHasGameData();
                    return;
                }
                System.out.println("Exiting App");
                finish();
                return;
            default:
                return;
        }
    }

    public boolean CheckIfNeedsReadPermission(Activity me) {
        String fileName = Helpers.getExpansionAPKFileName(this, true, this.xAPKS[0].mFileVersion);
        String baseDirectory = getObbDir().getAbsolutePath();
        boolean askForPermission = true;
        try {
            BufferedReader br = new BufferedReader(new FileReader(baseDirectory + "/" + fileName));
            br.read();
            br.close();
            askForPermission = false;
        } catch (Exception e) {
            System.out.println("Ask for read permission");
        }
        if (!askForPermission || ContextCompat.checkSelfPermission(me, "android.permission.READ_EXTERNAL_STORAGE") == 0) {
            return false;
        }
        this.waitForPermissions = true;
        this.delaySetContentView = true;
        if (ActivityCompat.shouldShowRequestPermissionRationale(me, "android.permission.READ_EXTERNAL_STORAGE")) {
            ActivityCompat.requestPermissions(me, new String[]{"android.permission.READ_EXTERNAL_STORAGE"}, (int) REQUEST_READ_EXTERNAL_STORAGE);
            return true;
        }
        ActivityCompat.requestPermissions(me, new String[]{"android.permission.READ_EXTERNAL_STORAGE"}, (int) REQUEST_READ_EXTERNAL_STORAGE);
        return true;
    }

    public boolean CopyFileFromAssets(String filename, String destPathName, boolean overwrite) {
        File ringtone = new File(destPathName);
        if (ringtone.exists()) {
            return false;
        }
        File destParentDir = ringtone.getParentFile();
        destParentDir.mkdirs();
        try {
            AssetManager assetManager = getAssets();
            InputStream in = assetManager.open(filename);
            OutputStream out = new FileOutputStream(destPathName);
            try {
                byte[] buffer = new byte[1024];
                while (true) {
                    int read = in.read(buffer);
                    if (read != -1) {
                        out.write(buffer, 0, read);
                    } else {
                        in.close();
                        out.flush();
                        out.close();
                        return true;
                    }
                }
            } catch (Exception e) {
                return false;
            }
        } catch (Exception e2) {
            return false;
        }
    }

    public boolean ConvertToBitmap(byte[] data, int length) {
        return false;
    }

    public boolean ServiceAppCommand(String cmd, String args) {
        return false;
    }

    public int ServiceAppCommandValue(String cmd, String args) {
        return 0;
    }

    public boolean ServiceAppCommandInt(String cmd, int args) {
        return false;
    }
}