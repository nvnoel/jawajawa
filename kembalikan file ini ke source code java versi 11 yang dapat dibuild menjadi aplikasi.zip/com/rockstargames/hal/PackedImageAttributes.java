package com.rockstargames.hal;

/* JADX INFO: Access modifiers changed from: package-private */
public class PackedImageAttributes {
    int height;
    int offsetX;
    int offsetY;
    int packedHeight;
    int packedWidth;
    TextureAtlas textureAtlas;
    int width;
    int x;
    int y;
}