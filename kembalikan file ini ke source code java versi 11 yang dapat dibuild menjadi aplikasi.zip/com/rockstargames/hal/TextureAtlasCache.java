package com.rockstargames.hal;

import android.graphics.Bitmap;
import android.support.v4.util.LruCache;

public class TextureAtlasCache extends LruCache<TextureAtlas, Bitmap> {
    public TextureAtlasCache(int maxSize) {
        super(maxSize);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public Bitmap create(TextureAtlas key) {
        return key.loadImage();
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public int sizeOf(TextureAtlas key, Bitmap value) {
        return value.getByteCount();
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public void entryRemoved(boolean evicted, TextureAtlas key, Bitmap oldValue, Bitmap newValue) {
    }
}