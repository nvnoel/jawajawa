package com.rockstargames.hal;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Log;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

public class TextureAtlas {
    private static boolean FORCE_ARGB4444 = false;
    Bitmap bitmap;
    private int flags;
    private float scale;
    private String bitmapName = null;
    private List<PackedImage> references = new ArrayList();

    public Bitmap getBitmap() {
        return this.bitmap != null ? this.bitmap : (Bitmap) ActivityWrapper.getTextureAtlasCache().get(this);
    }

    public static String getBitmapStats() {
        TextureAtlasCache tac = ActivityWrapper.getTextureAtlasCache();
        if (tac == null) {
            return "bmps: ";
        }
        int size = tac.size();
        if (size < 1024) {
            String s = "bmps: " + size + "b";
            return s;
        } else if (size < 1048576) {
            String s2 = "bmps: " + (size / 1024) + "k";
            return s2;
        } else {
            String s3 = "bmps: " + String.format("%.2fMB", Float.valueOf(size / 1048576.0f));
            return s3;
        }
    }

    public void setParameters(String name_, int flags_, float scale_) {
        this.bitmapName = name_;
        this.flags = flags_;
        this.scale = scale_;
    }

    public Bitmap loadImage() {
        return loadImage(false);
    }

    public InputStream getBitmapInputStream() throws IOException {
        return andFile.getAssetInputStream("images/" + this.bitmapName, false);
    }

    public Bitmap loadImage(boolean isRetrying) {
        Bitmap originalBitmap;
        if (this.bitmap != null) {
            return this.bitmap;
        }
        Bitmap returnBitmap = null;
        try {
            if (this.flags == 0) {
                originalBitmap = BitmapFactory.decodeStream(getBitmapInputStream());
            } else {
                BitmapFactory.Options opts = new BitmapFactory.Options();
                opts.inJustDecodeBounds = true;
                BitmapFactory.decodeStream(getBitmapInputStream(), null, opts);
                opts.inJustDecodeBounds = false;
                if (this.scale <= 0.25f) {
                    opts.inSampleSize = 4;
                    originalBitmap = BitmapFactory.decodeStream(getBitmapInputStream(), null, opts);
                } else if (this.scale <= 0.5f) {
                    opts.inSampleSize = 2;
                    originalBitmap = BitmapFactory.decodeStream(getBitmapInputStream(), null, opts);
                } else {
                    originalBitmap = BitmapFactory.decodeStream(getBitmapInputStream());
                }
                Log.e("TextureAtlas", "Scale in: " + this.scale + " scale, density: " + opts.inSampleSize);
            }
            if (FORCE_ARGB4444) {
                returnBitmap = originalBitmap.copy(Bitmap.Config.ARGB_4444, false);
                originalBitmap.recycle();
                return returnBitmap;
            }
            return originalBitmap;
        } catch (Exception ex) {
            ActivityWrapper.handleException(ex);
            return returnBitmap;
        } catch (OutOfMemoryError err) {
            Log.e("andImage", "TextureAtlas: Out of memory trying to create image: " + this.bitmapName, err);
            ActivityWrapper.getTextureAtlasCache().evictAll();
            andViewManager.invalidateHierarchy();
            System.gc();
            try {
                Thread.sleep(50L);
            } catch (Exception e) {
            }
            if (!isRetrying) {
                return loadImage(true);
            }
            if (this.flags == 1 && this.scale > 0.25f) {
                Log.e("andImage", "TextureAtlas: Trying again with scale = " + (this.scale / 2.0f));
                setParameters(this.bitmapName, this.flags | 1, this.scale / 2.0f);
                return loadImage(true);
            }
            Log.e("andImage", "TextureAtlas: Unable to free enough memory to load image " + this.bitmapName);
            return returnBitmap;
        }
    }

    public void LoadImageFromBitmap(String name, Bitmap image) {
        this.bitmap = image;
    }

    public void addReference(PackedImage pImage) {
        if (!this.references.contains(this.references)) {
            this.references.add(pImage);
        }
    }

    public boolean removeReference(PackedImage pImage) {
        if (this.references.contains(pImage)) {
            this.references.remove(pImage);
            if (this.references.size() == 0) {
                dump();
                return true;
            }
        }
        return false;
    }

    public void dump() {
        this.references.clear();
        if (this.bitmap != null) {
            this.bitmap.recycle();
            this.bitmap = null;
        }
    }

    public String toString() {
        return this.bitmapName + " " + super.toString();
    }
}