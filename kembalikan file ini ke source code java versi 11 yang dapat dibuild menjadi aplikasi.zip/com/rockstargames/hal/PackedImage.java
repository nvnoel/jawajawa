package com.rockstargames.hal;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.drawable.BitmapDrawable;
import android.util.Log;

public class PackedImage {
    PackedImageAttributes attributes;
    BitmapDrawable bitmapDrawable;
    Paint myPaint;
    private float scaleX;
    private float scaleY;
    Rect sourceRect;
    RectF targetRect;
    Bitmap tiledBitmap;
    boolean filteringTurnedOff = false;
    private ColorFilter previousFilter = null;
    private int previousDrawWidth = -1;
    private int previousDrawHeight = -1;

    public PackedImage(PackedImageAttributes attrs) {
        this.attributes = attrs;
        this.attributes.textureAtlas.addReference(this);
        this.targetRect = new RectF();
        this.sourceRect = new Rect();
        this.myPaint = new Paint();
        this.myPaint.setAntiAlias(true);
        this.myPaint.setFilterBitmap(true);
        this.sourceRect.left = getX();
        this.sourceRect.top = getY();
        this.sourceRect.right = getX() + getPackedWidth();
        this.sourceRect.bottom = getY() + getPackedHeight();
    }

    public TextureAtlas unload() {
        if (this.attributes.textureAtlas.removeReference(this)) {
            return this.attributes.textureAtlas;
        }
        return null;
    }

    public int getX() {
        return this.attributes.x;
    }

    public int getY() {
        return this.attributes.y;
    }

    public int getWidth() {
        return this.attributes.width;
    }

    public int getHeight() {
        return this.attributes.height;
    }

    public int getPackedWidth() {
        return this.attributes.packedWidth;
    }

    public int getPackedHeight() {
        return this.attributes.packedHeight;
    }

    public int getOffsetX() {
        return this.attributes.offsetX;
    }

    public int getOffsetY() {
        return this.attributes.offsetY;
    }

    public Bitmap getBitmap() {
        return this.attributes.textureAtlas.getBitmap();
    }

    public void turnOffFiltering() {
        if (!this.filteringTurnedOff) {
            this.filteringTurnedOff = true;
            this.myPaint.setAntiAlias(false);
            this.myPaint.setFilterBitmap(false);
            this.myPaint.setDither(false);
            this.sourceRect.left++;
            this.sourceRect.top++;
            this.sourceRect.right--;
            this.sourceRect.bottom--;
        }
    }

    public void Draw(Canvas canvas, int width, int height, boolean tiled) {
        Draw(canvas, width, height, tiled, null);
    }

    public void Draw(Canvas canvas, int width, int height, boolean tiled, ColorFilter filter) {
        boolean scaleChanged = false;
        if (width != this.previousDrawWidth || height != this.previousDrawHeight) {
            this.scaleX = width / getWidth();
            this.scaleY = height / getHeight();
            this.previousDrawWidth = width;
            this.previousDrawHeight = height;
            scaleChanged = true;
        }
        Bitmap bmp = getBitmap();
        if (filter != this.previousFilter) {
            this.myPaint.setColorFilter(filter);
            this.previousFilter = filter;
        }
        if (bmp == null) {
            Log.e("PackedImage", "PackedImage attempting to draw null bitmap!");
            canvas.drawColor(0, PorterDuff.Mode.CLEAR);
            return;
        }
        if (bmp.isRecycled()) {
            Log.e("PackedImage", "PackedImage attempting to draw recycled bitmap!");
            canvas.drawColor(0, PorterDuff.Mode.CLEAR);
            ActivityWrapper.getTextureAtlasCache().evictAll();
            System.gc();
            bmp = getBitmap();
        }
        if (bmp == null || bmp.isRecycled()) {
            Log.e("PackedImage", "PackedImage unable to reload recycled bitmap!");
            canvas.drawColor(0, PorterDuff.Mode.CLEAR);
        } else if (tiled) {
            if (this.tiledBitmap == null) {
                this.tiledBitmap = Bitmap.createBitmap(bmp, this.sourceRect.left, this.sourceRect.top, getWidth(), getHeight());
                this.bitmapDrawable = new BitmapDrawable(ActivityWrapper.getActivity().getResources(), this.tiledBitmap);
                this.bitmapDrawable.setTileModeXY(Shader.TileMode.REPEAT, Shader.TileMode.REPEAT);
            }
            this.bitmapDrawable.setBounds(0, 0, (int) (getWidth() * this.scaleX), (int) (getHeight() * this.scaleY));
            this.bitmapDrawable.draw(canvas);
        } else {
            if (scaleChanged) {
                this.targetRect.left = getOffsetX() * this.scaleX;
                this.targetRect.top = getOffsetY() * this.scaleY;
                this.targetRect.right = (getOffsetX() + getPackedWidth()) * this.scaleX;
                this.targetRect.bottom = (getOffsetY() + getPackedHeight()) * this.scaleY;
            }
            canvas.drawBitmap(bmp, this.sourceRect, this.targetRect, this.myPaint);
        }
    }
}