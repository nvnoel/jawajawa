package com.rockstargames.hal;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Log;
import java.io.ByteArrayOutputStream;
import java.util.HashMap;

public class andImage {
    private String name;
    private PackedImage packedImage;
    private static HashMap<String, TextureAtlas> hashMap = new HashMap<>();
    private static Bitmap caulk = null;

    public interface andImageReferencer {
        boolean hasReferenceTo(PackedImage packedImage);

        void removeReferencesTo(PackedImage packedImage);
    }

    public static Bitmap getCaulk() {
        if (caulk == null) {
            int[] cols = new int[16384];
            for (int i = 0; i < 16384; i++) {
                cols[i] = (i % 2 == 0) == ((i / 128) % 2 == 0) ? -16777216 : -65281;
            }
            caulk = Bitmap.createBitmap(cols, 128, 128, Bitmap.Config.RGB_565);
        }
        return caulk;
    }

    private static TextureAtlas getTextureAtlas(String name, int flags, float scale) {
        String name2 = name + ".png";
        TextureAtlas atlas = hashMap.get(name2);
        if (atlas == null) {
            atlas = new TextureAtlas();
            hashMap.put(name2, atlas);
        }
        atlas.setParameters(name2, flags, scale);
        atlas.getBitmap();
        return atlas;
    }

    private static TextureAtlas LoadImageFromBitmap(String name, Bitmap image) {
        TextureAtlas atlas = hashMap.get(name);
        if (atlas == null) {
            atlas = new TextureAtlas();
            hashMap.put(name, atlas);
        }
        atlas.LoadImageFromBitmap(name, image);
        return atlas;
    }

    private static void unloadPackedImage(PackedImage pImage) {
        TextureAtlas atlas = pImage.unload();
        if (atlas != null) {
            hashMap.remove(atlas);
        }
    }

    public static void dumpAllImages() {
        for (TextureAtlas atlas : hashMap.values()) {
            atlas.dump();
        }
        hashMap.clear();
    }

    public static andImage createImage(String name) {
        return new andImage(name);
    }

    public static andImage unpackImage(String name, String packedPath, int x, int y, int width, int height, int offsetX, int offsetY, int sizeWidth, int sizeHeight, int flags) {
        PackedImage packedImage = null;
        try {
            PackedImageAttributes attributes = new PackedImageAttributes();
            attributes.x = x;
            attributes.y = y;
            attributes.packedWidth = width;
            attributes.packedHeight = height;
            attributes.width = sizeWidth;
            attributes.height = sizeHeight;
            float screenW = ActivityWrapper.getWindowWidth();
            float screenH = ActivityWrapper.getWindowHeight();
            float scaleX = screenW / sizeWidth;
            float scaleY = screenH / sizeHeight;
            float scale = Math.max(scaleX, scaleY);
            attributes.textureAtlas = getTextureAtlas(packedPath, flags, scale);
            attributes.offsetX = offsetX;
            attributes.offsetY = offsetY;
            PackedImage packedImage2 = new PackedImage(attributes);
            packedImage = packedImage2;
        } catch (Exception ex) {
            Log.e("andImage", "Exception thrown when creating image:", ex);
        }
        return new andImage(name, packedImage);
    }

    public static andImage loadImageFromBytes(String name, byte[] data, int length) {
        Bitmap image = BitmapFactory.decodeByteArray(data, 0, length);
        if (image != null) {
            PackedImageAttributes attributes = new PackedImageAttributes();
            attributes.x = 0;
            attributes.y = 0;
            attributes.packedWidth = image.getWidth();
            attributes.packedHeight = image.getHeight();
            attributes.width = image.getWidth();
            attributes.height = image.getHeight();
            attributes.textureAtlas = LoadImageFromBitmap(name, image);
            attributes.offsetX = 0;
            attributes.offsetY = 0;
            PackedImage packedImage = new PackedImage(attributes);
            return new andImage(name, packedImage);
        }
        return null;
    }

    public andImage(String name) {
        this.name = name;
    }

    public andImage(String name, PackedImage packedImage) {
        this.name = name;
        this.packedImage = packedImage;
    }

    public int getWidth() {
        if (this.packedImage != null) {
            return this.packedImage.getWidth();
        }
        ActivityWrapper.handleException(new NullPointerException());
        return -1;
    }

    public int getHeight() {
        if (this.packedImage != null) {
            return this.packedImage.getHeight();
        }
        ActivityWrapper.handleException(new NullPointerException());
        return -1;
    }

    public PackedImage getPackedImage() {
        return this.packedImage;
    }

    public String getName() {
        return this.name;
    }

    public void unload() {
        if (this.packedImage == null) {
            Log.e("andImage", "Trying to recycle null bitmap!");
            return;
        }
        unloadPackedImage(this.packedImage);
        this.packedImage = null;
    }

    public byte[] getByteData() {
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        this.packedImage.getBitmap().compress(Bitmap.CompressFormat.PNG, 0, stream);
        return stream.toByteArray();
    }

    public void turnFilteringOff() {
        if (this.packedImage != null) {
            this.packedImage.turnOffFiltering();
        } else {
            Log.e("andImage", "Trying to make NULL packed image unfiltered");
        }
    }
}