package com.rockstargames.hal;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import com.facebook.FacebookRequestError;
import com.facebook.HttpMethod;
import com.facebook.Request;
import com.facebook.RequestAsyncTask;
import com.facebook.Response;
import com.facebook.Session;
import com.facebook.SessionLoginBehavior;
import com.facebook.SessionState;
import com.facebook.model.GraphUser;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import org.json.JSONException;
import org.json.JSONObject;

public class andFacebook {
    private static final String PENDING_PUBLISH_KEY = "pendingPublishReauthorization";
    private static String applicationId;
    private static andFacebook instance = null;
    private static final List<String> PERMISSIONS = Arrays.asList("publish_actions");
    static boolean test = true;
    private Session.StatusCallback statusCallback = new SessionStatusCallback();
    private boolean pendingPublishReauthorization = false;

    native void facebookClosed();

    native void facebookOpenedSucessfully(String str);

    native void facebookPostFailed();

    native void facebookPostSuccess();

    public static andFacebook getInstance() {
        if (instance == null) {
            instance = new andFacebook();
        }
        return instance;
    }

    public void onCreate() {
    }

    public void onStop() {
        Session session = Session.getActiveSession();
        if (session != null && session.isOpened()) {
            closeSession();
        }
    }

    public static boolean isSessionOpen() {
        Session session = Session.getActiveSession();
        return (session == null || !session.isOpened() || session.isClosed()) ? false : true;
    }

    public static void setApplicationID(String appID) {
        Session session = Session.getActiveSession();
        if (session != null) {
            String currentAppID = session.getApplicationId();
            if (appID != currentAppID) {
                closeAndClearTokenInformation();
            }
        }
        applicationId = appID;
    }

    public static void openSession() {
        openSession(false);
    }

    public static void openSession(boolean fromCache) {
        Session session = Session.getActiveSession();
        if (session == null) {
            if (session == null) {
                session = new Session.Builder(ActivityWrapper.getActivity()).setApplicationId(applicationId).build();
            }
            Session.setActiveSession(session);
        }
        boolean allowOpenSession = true;
        if (fromCache && session.getState() != SessionState.CREATED_TOKEN_LOADED) {
            allowOpenSession = false;
        }
        if (allowOpenSession) {
            if (!session.isOpened()) {
                Session.OpenRequest op = new Session.OpenRequest(ActivityWrapper.getActivity());
                op.setLoginBehavior(SessionLoginBehavior.SUPPRESS_SSO);
                op.setCallback((Session.StatusCallback) null);
                List<String> permissions = new ArrayList<>();
                permissions.add("basic_info");
                permissions.add("publish_actions");
                op.setPermissions(permissions);
                session.openForPublish(op);
                session.addCallback(getInstance().statusCallback);
                return;
            }
            Session.openActiveSession(ActivityWrapper.getActivity(), true, getInstance().statusCallback);
        }
    }

    public static void openSessionFromCache() {
        Session session = Session.getActiveSession();
        if (session == null) {
            openSession(true);
        }
    }

    public static void closeSession() {
        Session session = Session.getActiveSession();
        if (session != null) {
            session.close();
            Session.setActiveSession((Session) null);
        }
    }

    public static void closeAndClearTokenInformation() {
        Session session = Session.getActiveSession();
        if (session != null) {
            session.closeAndClearTokenInformation();
            session.close();
            Session.setActiveSession((Session) null);
        }
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        Session.getActiveSession().onActivityResult(ActivityWrapper.getActivity(), requestCode, resultCode, data);
    }

    private boolean isSubsetOf(Collection<String> subset, Collection<String> superset) {
        for (String string : subset) {
            if (!superset.contains(string)) {
                return false;
            }
        }
        return true;
    }

    public static void postMessage(String title, String description, String link, String pictureLink) {
        Session session = Session.getActiveSession();
        if (session != null) {
            List<String> permissions = session.getPermissions();
            if (!getInstance().isSubsetOf(PERMISSIONS, permissions)) {
                getInstance().pendingPublishReauthorization = true;
                Session.NewPermissionsRequest newPermissionsRequest = new Session.NewPermissionsRequest(ActivityWrapper.getActivity(), PERMISSIONS);
                session.requestNewPublishPermissions(newPermissionsRequest);
                return;
            }
            Bundle postParams = new Bundle();
            postParams.putString("name", title);
            postParams.putString("caption", " ");
            postParams.putString("description", description);
            postParams.putString("link", link);
            postParams.putString("picture", pictureLink);
            Request.Callback callback = new Request.Callback() { // from class: com.rockstargames.hal.andFacebook.1
                public void onCompleted(Response response) {
                    if (response != null) {
                        try {
                            JSONObject graphResponse = response.getGraphObject().getInnerJSONObject();
                            try {
                                graphResponse.getString("id");
                            } catch (JSONException e) {
                                Log.i("Facebook", "JSON error " + e.getMessage(), e);
                            }
                            FacebookRequestError error = response.getError();
                            if (error == null) {
                                andFacebook.getInstance().facebookPostSuccess();
                                return;
                            }
                        } catch (Exception ex) {
                            Log.e("andFacebook", "Error receiving Facebook response.", ex);
                        }
                    }
                    andFacebook.getInstance().facebookPostFailed();
                }
            };
            Request request = new Request(session, "me/feed", postParams, HttpMethod.POST, callback);
            RequestAsyncTask task = new RequestAsyncTask(new Request[]{request});
            task.execute(new Void[0]);
        }
    }

    private class SessionStatusCallback implements Session.StatusCallback {
        private SessionStatusCallback() {
        }

        public void call(Session session, SessionState state, Exception exception) {
            if (exception != null) {
                Log.i("Facebook", "Facebook error");
            }
            switch (AnonymousClass2.$SwitchMap$com$facebook$SessionState[state.ordinal()]) {
                case 1:
                    Request.executeMeRequestAsync(session, new Request.GraphUserCallback() { // from class: com.rockstargames.hal.andFacebook.SessionStatusCallback.1
                        public void onCompleted(GraphUser user, Response response) {
                            if (user != null) {
                                String name = user.getName();
                                andFacebook.this.facebookOpenedSucessfully(name);
                            }
                        }
                    });
                    return;
                case 2:
                    andFacebook.this.facebookClosed();
                    session.removeCallback(andFacebook.getInstance().statusCallback);
                    return;
                case 3:
                    andFacebook.closeSession();
                    session.removeCallback(andFacebook.getInstance().statusCallback);
                    return;
                default:
                    return;
            }
        }
    }

    /* renamed from: com.rockstargames.hal.andFacebook$2  reason: invalid class name */
    static  class AnonymousClass2 {
        static final  int[] $SwitchMap$com$facebook$SessionState = new int[SessionState.values().length];

        static {
            try {
                $SwitchMap$com$facebook$SessionState[SessionState.OPENED.ordinal()] = 1;
            } catch (NoSuchFieldError e) {
            }
            try {
                $SwitchMap$com$facebook$SessionState[SessionState.CLOSED.ordinal()] = 2;
            } catch (NoSuchFieldError e2) {
            }
            try {
                $SwitchMap$com$facebook$SessionState[SessionState.CLOSED_LOGIN_FAILED.ordinal()] = 3;
            } catch (NoSuchFieldError e3) {
            }
        }
    }
}